/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        var Internal;
        (function (Internal) {
            var emptyString = "";
            var OpenPresenceDialogControl = /** @class */ (function () {
                // Empty Constructor
                function OpenPresenceDialogControl() {
                    var _a, _b;
                    this.isPresenceCommandFirstTimeLoad = false;
                    this.isDifferentIframeLoad = false;
                    this.isPresenceCommandFirstTimeLoad = true;
                    try {
                        if (!((_b = (_a = window.top) === null || _a === void 0 ? void 0 : _a.Microsoft) === null || _b === void 0 ? void 0 : _b.CIFramework)) {
                            this.isDifferentIframeLoad = true;
                            return;
                        }
                        else if (!window.top.Microsoft.CIFramework.PresenceCommand) {
                            window.top.Microsoft.CIFramework.PresenceCommand = {};
                            window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred = {
                                promise: null,
                                resolve: null,
                                reject: null
                            };
                            window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.promise = new Promise(function (resolve, reject) {
                                window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.resolve = resolve;
                                window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.reject = reject;
                            });
                            window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.promise = this.makeQuerablePromise(window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.promise);
                        }
                        this.processPresenceCommand();
                    }
                    catch (error) {
                        // If DOMException, loading in different iframe
                        if (error instanceof DOMException) {
                            this.isDifferentIframeLoad = true;
                        }
                    }
                }
                Object.defineProperty(OpenPresenceDialogControl, "Instance", {
                    get: function () {
                        if (this.instance == null) {
                            this.instance = new OpenPresenceDialogControl();
                        }
                        return this.instance;
                    },
                    enumerable: false,
                    configurable: true
                });
                OpenPresenceDialogControl.prototype.openPresenceDialog = function (e) {
                    if (!window.localStorage[OpenPresenceDialogControl.CURRENT_PRESENCE_INFO]) {
                        return;
                    }
                    var dialogParams = {};
                    dialogParams[OpenPresenceDialogControl.LAST_BUTTON_CLICKED] = "";
                    var dialogOptions = { width: 300, height: 300, position: 1 /* center */ };
                    Xrm.Navigation.openDialog(OpenPresenceDialogControl.SET_PRESENCE_MDD, dialogOptions, dialogParams);
                };
                OpenPresenceDialogControl.prototype.addPresenceCommand = function (e) {
                    var _this = this;
                    var _a, _b, _c, _d;
                    if (this.isDifferentIframeLoad) {
                        return Promise.resolve(false);
                    }
                    setTimeout(function () {
                        var _a, _b, _c, _d, _e;
                        if (_this.isPresenceCommandFirstTimeLoad && !((_e = (_d = (_c = (_b = (_a = window.top) === null || _a === void 0 ? void 0 : _a.Microsoft) === null || _b === void 0 ? void 0 : _b.CIFramework) === null || _c === void 0 ? void 0 : _c.PresenceCommand) === null || _d === void 0 ? void 0 : _d.presenceCommandDeferred) === null || _e === void 0 ? void 0 : _e.promise).isFulfilled()) {
                            window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.resolve(false);
                        }
                    }, 9500);
                    window.localStorage[OpenPresenceDialogControl.CURRENT_PRESENCE_INFO] = emptyString;
                    if ((_d = (_c = (_b = (_a = window.top) === null || _a === void 0 ? void 0 : _a.Microsoft) === null || _b === void 0 ? void 0 : _b.CIFramework) === null || _c === void 0 ? void 0 : _c.PresenceCommand) === null || _d === void 0 ? void 0 : _d.presenceCommandDeferred) {
                        return window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.promise;
                    }
                    else {
                        return Promise.resolve(false);
                    }
                };
                OpenPresenceDialogControl.prototype.processPresenceCommand = function () {
                    var _this = this;
                    this.shouldInvokeCompatibilityCheckAction().then(function (result) {
                        if (result === true && window.localStorage[OpenPresenceDialogControl.currentOrgCecCompaitbility] === undefined) {
                            var request = {
                                // TODO: Need to pass other parameters when available
                                getMetadata: function () {
                                    return {
                                        boundParameter: null,
                                        parameterTypes: {},
                                        operationType: 0,
                                        operationName: "msdyn_GetCecCompatibilityForOmniChannel"
                                    };
                                }
                            };
                            Xrm.WebApi.online.execute(request).then(function (data) {
                                data.json().then(function (response) {
                                    var IsResolvedLegacyCommand = JSON.parse(response.IsResolvedLegacyCommand);
                                    window.localStorage[OpenPresenceDialogControl.currentOrgCecCompaitbility] = IsResolvedLegacyCommand;
                                    if (!IsResolvedLegacyCommand) {
                                        _this.resolvePresenceCommandLegacy();
                                    }
                                });
                            }, function (error) {
                                _this.resolvePresenceCommandLegacy();
                            });
                        }
                        else if (result === true && window.localStorage[OpenPresenceDialogControl.currentOrgCecCompaitbility] === "false") {
                            _this.resolvePresenceCommandLegacy();
                        }
                        else if (result === false) {
                            _this.resolvePresenceCommandLegacy();
                        }
                    });
                };
                OpenPresenceDialogControl.prototype.makeQuerablePromise = function (promise) {
                    // Don't modify any promise that has been already modified.
                    if (promise.isResolved)
                        return promise;
                    // Set initial state
                    var isPending = true;
                    var isRejected = false;
                    var isFulfilled = false;
                    // Observe the promise, saving the fulfillment in a closure scope.
                    var result = promise.then(function (v) {
                        isFulfilled = true;
                        isPending = false;
                        return v;
                    }, function (e) {
                        isRejected = true;
                        isPending = false;
                        throw e;
                    });
                    result.isFulfilled = function () { return isFulfilled; };
                    result.isPending = function () { return isPending; };
                    result.isRejected = function () { return isRejected; };
                    return result;
                };
                OpenPresenceDialogControl.prototype.resolvePresenceCommandLegacy = function () {
                    var appUniqueName = "";
                    var globalContext = Xrm.Utility.getGlobalContext();
                    globalContext.getCurrentAppProperties().then(function (response) {
                        var _a, _b, _c, _d;
                        if ((_d = (_c = (_b = (_a = window.top) === null || _a === void 0 ? void 0 : _a.Microsoft) === null || _b === void 0 ? void 0 : _b.CIFramework) === null || _c === void 0 ? void 0 : _c.PresenceCommand) === null || _d === void 0 ? void 0 : _d.presenceCommandDeferred) {
                            appUniqueName = response.uniqueName;
                            // As of now, presence control can be shown only in OC and Dfm app.
                            if (appUniqueName === "OmniChannelEngagementHub" || appUniqueName === "msdfm_DynamicsForMicrosoft") {
                                window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.resolve(true);
                            }
                            else {
                                window.top.Microsoft.CIFramework.PresenceCommand.presenceCommandDeferred.resolve(false);
                            }
                        }
                    });
                };
                OpenPresenceDialogControl.prototype.shouldInvokeCompatibilityCheckAction = function () {
                    var appUniqueName = "";
                    return new Promise(function (resolve, reject) {
                        var globalContext = Xrm.Utility.getGlobalContext();
                        var orgId = globalContext.organizationSettings.organizationId;
                        globalContext.getCurrentAppProperties().then(function (response) {
                            appUniqueName = response.uniqueName;
                            OpenPresenceDialogControl.currentOrgCecCompaitbility = orgId + OpenPresenceDialogControl.CEC_COMPATIBILITY;
                            // As of now, presence control can be shown only in OC and Dfm app.
                            if (appUniqueName === "OmniChannelEngagementHub" || appUniqueName === "msdyn_CustomerServiceWorkspace") {
                                resolve(true);
                            }
                            else {
                                resolve(false);
                            }
                        });
                    });
                };
                OpenPresenceDialogControl.CURRENT_PRESENCE_INFO = "GlobalToolBar_CurrentPresenceInfo";
                OpenPresenceDialogControl.LAST_BUTTON_CLICKED = "param_lastButtonClicked";
                OpenPresenceDialogControl.SET_PRESENCE_MDD = "SetAgentPresenceMDD";
                OpenPresenceDialogControl.CEC_COMPATIBILITY = "_CecCompatibilityForOmniChannel";
                OpenPresenceDialogControl.currentOrgCecCompaitbility = "";
                return OpenPresenceDialogControl;
            }());
            Internal.OpenPresenceDialogControl = OpenPresenceDialogControl;
        })(Internal = CIFramework.Internal || (CIFramework.Internal = {}));
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
//# sourceMappingURL=msdyn_cec_internal_openDialog_ci_library.js.map