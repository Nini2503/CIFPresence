/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * Constants for CIFramework.
 */
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        var postMessageNamespace;
        (function (postMessageNamespace) {
            /**
             * retry count for post message function
             */
            postMessageNamespace.retryCount = 3;
            /**
             * wait time for receiving a response from the listener window, before we reject the promise
             */
            postMessageNamespace.promiseTimeOut = 10000; // in milliseconds
            /**
             * String for correlationId to be used as a key.
             */
            postMessageNamespace.messageCorrelationId = 'messageCorrelationId';
            /**
             * String to represent a successful result.
             */
            postMessageNamespace.messageSuccess = 'success';
            postMessageNamespace.messageFailure = 'failure';
            /**
             * String to represent a web-socket message.
             */
            postMessageNamespace.messageConstant = 'message';
            postMessageNamespace.originURL = 'originURL';
            postMessageNamespace.message = 'message';
            postMessageNamespace.messageResponse = 'CIF_Response';
            /**
            * utility func to create a promise and reject it with the passed error message
            */
            function rejectWithErrorMessage(errorMessage) {
                return Promise.reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(Microsoft.CIFramework.Utility.createErrorMap(errorMessage))));
            }
            postMessageNamespace.rejectWithErrorMessage = rejectWithErrorMessage;
        })(postMessageNamespace = CIFramework.postMessageNamespace || (CIFramework.postMessageNamespace = {}));
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
// export { };
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * Constants for CIFramework.
 */
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        var Utility;
        (function (Utility) {
            const webresourceName = "Localization/CIF_webresource_strings";
            function getResourceString(key) {
                let value = key;
                if (Xrm && Xrm.Utility && Xrm.Utility.getResourceString) {
                    value = Xrm.Utility.getResourceString(webresourceName, key);
                    if (value === undefined || value === null) {
                        value = key;
                    }
                }
                return value;
            }
            Utility.getResourceString = getResourceString;
            /**
             * utility func to create a error map with the error message and optional error code
            */
            function createErrorMap(errorMessage, apiName) {
                return new Map().set(CIFramework.Constants.message, errorMessage).set(CIFramework.Constants.nameParameter, apiName);
            }
            Utility.createErrorMap = createErrorMap;
            /**
             * utility func to check whether argument passed if of type Error Object
             * @param arg Object to check whether it is Error or not.
            */
            function isError(arg) {
                return (arg.message !== undefined);
            }
            Utility.isError = isError;
            function launchSearchPage(searchQuery, entityName) {
                try {
                    const searchPageInput = {
                        pageType: "search",
                        searchText: Microsoft.CIFramework.Utility.extractSearchText(searchQuery),
                        searchType: 1,
                        EntityNames: [entityName],
                        EntityGroupName: "",
                    };
                    const xrmInstance = (window.top.getCurrentXrm()) || Xrm;
                    xrmInstance.Navigation.navigateTo(searchPageInput);
                }
                catch (error) {
                    //
                }
            }
            Utility.launchSearchPage = launchSearchPage;
            /**
             * Given a key-value object, this func returns an equivalent Map object for it.
             * @param dict Object to build the map for.
             */
            function buildMap(dict) {
                if (isError(dict)) {
                    return createErrorMap(dict.message);
                }
                else {
                    const map = new Map();
                    Object.keys(dict).forEach((key) => {
                        map.set(key, dict[key]);
                    });
                    return map;
                }
            }
            Utility.buildMap = buildMap;
            /**
             * Generic method to convert map data into string
             * @param map
             */
            function mapToString(map, exclusionList = []) {
                let result = "";
                if (!map) {
                    return "";
                }
                map.forEach((value, key) => {
                    if (exclusionList.indexOf(key) === -1) {
                        result += key + " : " + value + ", ";
                    }
                });
                return result;
            }
            Utility.mapToString = mapToString;
            function flatten(obj) {
                const ret = {};
                if (Object.getPrototypeOf(obj) == null || Object.getPrototypeOf(obj) === "undefined")
                    return obj;
                const propNames = Object.getOwnPropertyNames(Object.getPrototypeOf(obj)).filter(n => n !== 'constructor');
                // tslint:disable-next-line:forin
                for (const pi in propNames) {
                    const prop = propNames[pi];
                    if (typeof (obj[prop]) === "object") {
                        ret[prop] = flatten(obj[prop]);
                    }
                    else {
                        ret[prop] = obj[prop];
                    }
                }
                return ret;
            }
            Utility.flatten = flatten;
            /**
             * Given a map, this func returns an equivalent XrmClientApi.WebApi.Entity object for it.
             * @param map Object to build the entity for.
             */
            function buildEntity(map) {
                const entity = {};
                map.forEach((value, key) => {
                    entity[key] = value;
                });
                return entity;
            }
            Utility.buildEntity = buildEntity;
            function extractParameter(queryString, parameterName) {
                const params = {};
                if (queryString) {
                    const queryStringArray = queryString.substr(1).split("&");
                    queryStringArray.forEach((query) => {
                        const queryPair = query.split("=");
                        const queryKey = decodeURIComponent(queryPair.shift());
                        const queryValue = decodeURIComponent(queryPair.join("="));
                        params[queryKey] = queryValue;
                    });
                }
                if (params.hasOwnProperty(parameterName))
                    return params[parameterName];
                else
                    return "";
            }
            Utility.extractParameter = extractParameter;
            function extractSearchText(queryString) {
                const emptyString = "";
                if (queryString) {
                    const query = queryString.split("=");
                    return (query[1] != null && query[1] !== "") ? query[1] : emptyString;
                }
                return emptyString;
            }
            Utility.extractSearchText = extractSearchText;
            function splitQueryForSearch(queryString) {
                let splitQuery = [];
                if (queryString) {
                    splitQuery = queryString.split("&");
                }
                const splitSearchQuery = ["", ""];
                splitQuery.forEach((query) => {
                    if (!query.startsWith("$search") && !query.startsWith("?$search")) {
                        splitSearchQuery[0] === "" ? splitSearchQuery[0] += query : splitSearchQuery[0] += "&" + query;
                    }
                    else {
                        splitSearchQuery[1] = query;
                    }
                });
                if (!splitSearchQuery[0].startsWith("?")) {
                    splitSearchQuery[0] = "?" + splitSearchQuery[0];
                }
                if (splitSearchQuery[1].startsWith("?")) {
                    splitSearchQuery[1] = splitSearchQuery[1].substr(1);
                }
                return splitSearchQuery;
            }
            Utility.splitQueryForSearch = splitQueryForSearch;
            /**
             * Converts given rgb value to hex value
             */
            function rgb2hex(value) {
                const rgb = value.replace(/\s/g, '').match(/^rgba?\((\d+),(\d+),(\d+)/i);
                return (rgb && rgb.length === 4) ? "#" +
                    ("0" + parseInt(rgb[1], 10).toString(16)).slice(-2).toUpperCase() +
                    ("0" + parseInt(rgb[2], 10).toString(16)).slice(-2).toUpperCase() +
                    ("0" + parseInt(rgb[3], 10).toString(16)).slice(-2).toUpperCase() : value;
            }
            Utility.rgb2hex = rgb2hex;
            /**
             * Utility to get element by id from iframe
             */
            function getElementFromIframe(iFrameObject, id) {
                return iFrameObject.contentWindow.document.getElementById(id);
            }
            Utility.getElementFromIframe = getElementFromIframe;
            /**
             * Utility to get elements by classname from iframe
             */
            function getElementsByClassName(iFrameObject, className) {
                return iFrameObject.contentWindow.document.getElementsByClassName(className);
            }
            Utility.getElementsByClassName = getElementsByClassName;
            function blinkBrowserTab(iFrameObject) {
                if (iFrameObject.contentWindow.document.hasFocus() || window.top.titleAnimation === true) {
                    return;
                }
                const originalTitle = window.top.document.title; // save original title
                const animatedTitle = "New notification";
                const timer = setInterval(startAnimation, 800);
                window.top.titleAnimation = true;
                function startAnimation() {
                    // animate between the original and the new title
                    window.top.document.title = window.top.document.title === animatedTitle ? originalTitle : animatedTitle;
                }
                const restoreTitleFunction = function restoreTitle() {
                    clearInterval(timer);
                    window.top.document.title = originalTitle; // restore original title
                    window.top.titleAnimation = false;
                    iFrameObject.contentWindow.removeEventListener("focus", restoreTitleFunction);
                };
                // Change page title back on focus
                iFrameObject.contentWindow.addEventListener("focus", restoreTitleFunction);
            }
            Utility.blinkBrowserTab = blinkBrowserTab;
            /**
             * Utility to compare crm versions. Returns true if version1 >= version2, false if version1 < version2
             */
            function compareVersion(version1, version2) {
                const version1parts = version1.split('.');
                const version2parts = version2.split('.');
                if (version1parts.length !== version2parts.length) {
                    return false;
                }
                for (let i = 0; i < version1parts.length; ++i) {
                    const v1 = parseInt(version1parts[i], 10);
                    const v2 = parseInt(version2parts[i], 10);
                    if (v1 > v2) {
                        return true;
                    }
                    else if (v1 < v2) {
                        return false;
                    }
                }
                return true;
            }
            Utility.compareVersion = compareVersion;
            function onFormSaveHandler(context) {
                const sessionId = window.top.Xrm.App.sessions.getFocusedSession().sessionId;
                const tabId = window.top.Xrm.App.sessions.getFocusedSession().tabs.getFocusedTab().tabId;
                const preNavigateHandler = (event) => {
                    window.top.Xrm.Navigation.removeOnPreNavigation(preNavigateHandler);
                    window.top.Xrm.App.sessions.getSession(sessionId).tabs.getTab(tabId).close();
                };
                const intervalFunction = setInterval(() => {
                    try {
                        const formContext = context.getFormContext();
                        const entityId = formContext.data.entity.getId();
                        if (entityId !== "") {
                            clearInterval(intervalFunction);
                            window.top.dispatchEvent(new CustomEvent("entityRecordSaved", {
                                detail: {
                                    entityLogicalName: formContext.data.entity.getEntityName(),
                                    entityId: entityId.replace(/[{}]/g, '')
                                }
                            }));
                            if (context.getEventArgs().getSaveMode() === 2) { // save and close
                                window.top.Xrm.Navigation.addOnPreNavigation(preNavigateHandler);
                            }
                        }
                    }
                    catch (error) {
                        clearInterval(intervalFunction);
                        // tslint:disable-next-line:no-console
                        console.log("Error in onFormSaveHandler. " + error);
                    }
                }, 100);
                window.top.Xrm.Page.data.entity.removeOnSave(Microsoft.CIFramework.Utility.onFormSaveHandler);
            }
            Utility.onFormSaveHandler = onFormSaveHandler;
            function newGuid() {
                const guidRegex = /[xy]/g;
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(guidRegex, (c) => {
                    // tslint:disable-next-line:no-bitwise
                    const r = (Math.random() * 16 | 0);
                    // tslint:disable-next-line:no-bitwise
                    const v = (c === 'x' ? r : r & 0x3 | 0x8);
                    return v.toString(16);
                });
            }
            Utility.newGuid = newGuid;
        })(Utility = CIFramework.Utility || (CIFramework.Utility = {}));
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
    * @license Copyright (c) Microsoft Corporation. All rights reserved.
    */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        /**
            * All the message types/ APIs that are exposed to the widget
        */
        let MessageType = /** @class */ (() => {
            class MessageType {
            }
            MessageType.setClickToAct = "setclicktoact";
            MessageType.getClickToAct = "getclicktoact";
            MessageType.searchAndOpenRecords = "searchandopenrecords";
            MessageType.openForm = "openform";
            MessageType.refreshForm = "refreshform";
            MessageType.createRecord = "createrecord";
            MessageType.deleteRecord = "deleterecord";
            MessageType.retrieveRecord = "retrieverecord";
            MessageType.retrieveMultipleRecords = "retrieveMultipleRecords";
            MessageType.updateRecord = "updaterecord";
            MessageType.search = "search";
            MessageType.setMode = "setmode";
            MessageType.setWidth = "setwidth";
            MessageType.getMode = "getmode";
            MessageType.getEnvironment = "getenvironment";
            MessageType.getWidth = "getwidth";
            MessageType.onClickToAct = "onclicktoact";
            MessageType.onModeChanged = "onmodechanged";
            MessageType.onSizeChanged = "onsizechanged";
            MessageType.onPageNavigate = "onpagenavigate";
            MessageType.onSendKBArticle = "onsendkbarticle";
            MessageType.onSetPresence = "onSetPresence";
            MessageType.onSessionSwitched = "onSessionSwitched";
            MessageType.onSessionIdle = "onSessionIdle";
            MessageType.onUserActivity = "onUserActivity";
            MessageType.onSessionCreated = "onSessionCreated";
            MessageType.onBeforeSessionClosed = "onBeforeSessionClosed";
            MessageType.onSessionClosed = "onSessionClosed";
            MessageType.getEntityMetadata = "getEntityMetadata";
            MessageType.notifyEvent = "notifyEvent";
            MessageType.softNotification = "softNotification";
            MessageType.broadCast = "broadCast";
            MessageType.internalCommunication = "internalCommunication";
            MessageType.notification = "notification";
            MessageType.transfer = "transfer";
            MessageType.escalation = "escalation";
            MessageType.renderSearchPage = "renderSearchPage";
            MessageType.requestFocusSession = "requestFocusSession";
            MessageType.getAllSessions = "getAllSessions";
            MessageType.getFocusedSession = "getFocusedSession";
            MessageType.getSession = "getSession";
            MessageType.canCreateSession = "canCreateSession";
            MessageType.createSession = "createSession";
            MessageType.getFocusedTab = "getFocusedTab";
            MessageType.getTabsByTagOrName = "getTabsByTagOrName";
            MessageType.refreshTab = "refreshTab";
            MessageType.setSessionTitle = "setSessionTitle";
            MessageType.setTabTitle = "setTabTitle";
            MessageType.createTab = "createTab";
            MessageType.createTabInHomeSession = "createTabInHomeSession";
            MessageType.focusTab = "focusTab";
            MessageType.closeTab = "closeTab";
            MessageType.onMaxSessionsReached = "onMaxSessionsReached";
            MessageType.setAgentPresence = "setAgentPresence";
            MessageType.setPresence = "setPresence";
            MessageType.getPresence = "getPresence";
            MessageType.initializeAgentPresenceList = "initializeAgentPresenceList";
            MessageType.insertNotes = "insertNotes";
            MessageType.openKBSearchControl = "openkbsearchcontrol";
            MessageType.onSetPresenceEvent = "setPresenceEvent";
            MessageType.hardNotification = "hardNotification";
            MessageType.removeGenericHandler = "removeGenericHandler";
            MessageType.addGenericHandler = "addGenericHandler";
            MessageType.setPosition = "setPosition";
            MessageType.isConsoleApp = "isConsoleApp";
            MessageType.getPosition = "getPosition";
            MessageType.doSearch = "doSearch";
            MessageType.initializeCI = "initializeCI";
            MessageType.loadProvider = "loadProvider";
            MessageType.openDialog = "openDialog";
            MessageType.logErrorsAndReject = "logErrorsAndReject";
            MessageType.initLogAnalytics = "initLogAnalytics";
            MessageType.logAnalyticsEvent = "logAnalyticsEvent";
            MessageType.updateContext = "updateContext";
            MessageType.notifyKpiBreach = "notifyKpiBreach";
            MessageType.notifyNewActivity = "notifyNewActivity";
            MessageType.updateConversation = "updateConversation";
            MessageType.setOCInstallStatus = "setOCInstallStatus";
            MessageType.onKeyDownEvent = "keydown";
            MessageType.fetchDebugData = "fetchDebugData";
            MessageType.debugInformationEvent = "debugInformationEvent";
            MessageType.showGlobalNotification = "showGlobalNotification";
            MessageType.clearGlobalNotification = "clearGlobalNotification";
            MessageType.onResetPresenceEvent = "resetPresenceEvent";
            MessageType.showTimeoutGlobalNotification = "showTimeoutGlobalNotification";
            MessageType.executeFetchQuery = "executeFetchQuery";
            MessageType.notificationDisplayEvent = "notificationDisplayEvent";
            MessageType.sessionVisibilityEvent = "sessionVisibilityEvent";
            MessageType.windowFocusEvent = "windowFocusEvent";
            MessageType.showProgressIndicator = "showProgressIndicator";
            MessageType.closeProgressIndicator = "closeProgressIndicator";
            MessageType.openMDDDialog = "openMDDDialog";
            MessageType.executeAction = "executeAction";
            MessageType.closeNotes = "closeNotes";
            MessageType.getFcsValue = "getFcsValue";
            MessageType.raiseEvent = "raiseEvent";
            return MessageType;
        })();
        CIFramework.MessageType = MessageType;
        let ScenarioState = /** @class */ (() => {
            class ScenarioState {
            }
            ScenarioState.Started = "Started";
            ScenarioState.Completed = "Completed";
            return ScenarioState;
        })();
        CIFramework.ScenarioState = ScenarioState;
        let ScenarioStatus = /** @class */ (() => {
            class ScenarioStatus {
            }
            ScenarioStatus.Success = "Success";
            ScenarioStatus.Failure = "Failure";
            return ScenarioStatus;
        })();
        CIFramework.ScenarioStatus = ScenarioStatus;
        let ScenarioEvent = /** @class */ (() => {
            class ScenarioEvent {
            }
            ScenarioEvent.NotificationReceived = "NotificationReceived";
            ScenarioEvent.InitAgentPresenceList = "InitAgentPresenceList";
            ScenarioEvent.SetAgentPresence = "SetAgentPresence";
            ScenarioEvent.InitCIF = "InitCIF";
            return ScenarioEvent;
        })();
        CIFramework.ScenarioEvent = ScenarioEvent;
        let OpenAppTabType = /** @class */ (() => {
            class OpenAppTabType {
            }
            OpenAppTabType.data = "data";
            OpenAppTabType.url = "url";
            OpenAppTabType.relationship = "relationship";
            OpenAppTabType.createFromEntity = "createfromentity";
            OpenAppTabType.searchType = "searchtype";
            OpenAppTabType.CustomControlInputString = "customcontrol";
            OpenAppTabType.ThirdPartyWebsiteInputString = "websiteurl";
            OpenAppTabType.ThirdPartyWebsiteInputString1 = "thirdpartywebsite";
            OpenAppTabType.EntityViewInputString = "entityview";
            OpenAppTabType.DashboardInputString = "dashboard";
            OpenAppTabType.EntityRecordInputString = "entityrecord";
            OpenAppTabType.EntitySearchInputString = "entitysearch";
            OpenAppTabType.WebResourceInputString = "webresource";
            OpenAppTabType.control = "control";
            OpenAppTabType.dashboard = "dashboard";
            OpenAppTabType.entitylist = "entitylist";
            OpenAppTabType.entityrecord = "entityrecord";
            OpenAppTabType.search = "search";
            OpenAppTabType.webresource = "webresource";
            // keeping thirthpartyWebsite as weresource as currently we are not able to access
            // CIF public API and we are consuming Microsoft.CIFramework.External.CIFExternalUtilityImpl() to create tab
            OpenAppTabType.thirdPartyWebsite = "webresource"; // ThirdPartyWebsite
            return OpenAppTabType;
        })();
        CIFramework.OpenAppTabType = OpenAppTabType;
        /**
            * All constants for widget side logic should be placed here
        */
        let Constants = /** @class */ (() => {
            class Constants {
            }
            Constants.notificationId = "notificationId";
            Constants.value = "value";
            Constants.entityName = "entityName";
            Constants.entityId = "entityId";
            Constants.queryParameters = "queryParameters";
            Constants.options = "options";
            Constants.message = "message";
            Constants.searchOnly = "searchOnly";
            Constants.entityFormOptions = "entityFormOptions";
            Constants.entityFormParameters = "entityFormParameters";
            Constants.Save = "save";
            Constants.ScriptIdAttributeName = "data-cifid";
            Constants.ScriptIdAttributeValue = "CIFMainLibrary";
            Constants.ScriptCRMUrlAttributeName = "data-crmurl";
            Constants.nameParameter = "msdyn_name";
            Constants.originURL = "originURL";
            Constants.CIClickToAct = "CIClickToAct";
            Constants.CISendKBArticle = "KMClickToSend";
            Constants.SetPresenceEvent = "setPresenceEvent";
            Constants.widgetIframeId = "SidePanelIFrame";
            Constants.clickToActAttributeName = "msdyn_clicktoact";
            Constants.enableAnalyticsAttributeName = "msdyn_enableanalytics";
            Constants.systemUserLogicalName = "systemuser";
            Constants.templateTag = "templateTag";
            Constants.appSelectorFieldName = "msdyn_appselector";
            Constants.sortOrderFieldName = "msdyn_sortorder";
            Constants.roleSelectorFieldName = "msdyn_roleselector";
            Constants.providerOdataQuery = "?$select=fullname&$expand=msdyn_ciprovider_systemuser_membership($filter=statecode eq 0;$orderby=msdyn_sortorder asc,createdon asc;$top={0})";
            Constants.providerNavigationProperty = "msdyn_ciprovider_systemuser_membership";
            Constants.providerId = "msdyn_ciproviderid";
            Constants.landingUrl = "msdyn_landingurl";
            Constants.label = "msdyn_label";
            Constants.providerLogicalName = "msdyn_ciprovider";
            Constants.widgetHeight = "msdyn_widgetheight";
            Constants.widgetWidth = "msdyn_widgetwidth";
            Constants.SizeChangeHandler = "sizeChangeHandler";
            Constants.ModeChangeHandler = "modeChangedHandler";
            Constants.NavigationHandler = "NavigationHandler";
            Constants.AppName = "appName";
            Constants.ClientUrl = "clientUrl";
            Constants.AppUrl = "appUrl";
            Constants.Theme = "themeName";
            Constants.darkTheme = "dark";
            Constants.lightTheme = "light";
            Constants.OrgLcid = "orgLcid";
            Constants.OrgUniqueName = "orgUniqueName";
            Constants.UserId = "userId";
            Constants.UserLcid = "userLcid";
            Constants.UserName = "username";
            Constants.UserRoles = "userRoles";
            Constants.DefaultCountryCode = "defaultCountryCode";
            Constants.MinimizedHeight = 34;
            Constants.DefaultFullWidth = 100;
            Constants.APIVersion = "msdyn_ciproviderapiversion";
            Constants.SortOrder = "msdyn_sortorder";
            Constants.crmVersion = "crmVersion";
            Constants.cifVersion = "cifVersion";
            Constants.CIFInitEvent = "CIFInitDone";
            Constants.Attributes = "attributes";
            Constants.UciLib = "ucilib";
            Constants.OrgId = "orgId";
            Constants.TenantId = "tenantId";
            Constants.trustedDomain = "msdyn_trusteddomain";
            Constants.customParams = "msdyn_customparams";
            Constants.customParamsKey = "customParams";
            Constants.eventType = "eventType";
            Constants.headerDataCIF = "headerDataCIF";
            Constants.bodyDataCIF = "bodyDataCIF";
            Constants.notificationUXObject = "notificationUXObject";
            Constants.actionDisplayText = "actionDisplayText";
            Constants.actionReturnValue = "actionReturnValue";
            Constants.actionsCIF = "actions";
            Constants.actionName = "actionName";
            Constants.responseReason = "responseReason";
            Constants.CIFNotificationIcon = "CIFNotificationIcon";
            Constants.actionColor = "actionColor";
            Constants.actionImage = "actionImage";
            Constants.Timeout = "Timeout";
            Constants.Accept = "Accept";
            Constants.Reject = "Reject";
            Constants.actionType = "actionType";
            Constants.notificationType = "notificationType";
            Constants.Timer = "Timer";
            Constants.NoOfNotifications = "NoOfNotifications";
            Constants.SMS = "sms";
            Constants.Chat = "chat";
            Constants.Facebook = "facebook";
            Constants.Twitter = "twitter";
            Constants.Custom = "custom";
            Constants.Call = "call";
            Constants.Informational = "informational";
            Constants.Failure = "failure";
            Constants.Case = "case";
            Constants.SearchString = "searchString";
            Constants.input = "input";
            Constants.context = "context";
            Constants.customerName = "customerName";
            Constants.sessionId = "sessionId";
            Constants.tabId = "tabId";
            Constants.messagesCount = "messagesCount";
            Constants.shouldReset = "shouldReset";
            Constants.MaxSessions = 5;
            Constants.sessionColors = ["#2A757D", "#70278B", "#FF8C00", "#427825", "#B4009E", "#B4A0FF"];
            Constants.sessionPanel = "sessionPanel";
            Constants.DEFAULT_WIDGET_WIDTH = 378;
            Constants.DEFAULT_SIDEPANEL_WIDTH = 34;
            Constants.DEFAULT_SIDEPANEL_WIDTH_WITH_BORDER = 36;
            Constants.presenceInfo = "presenceInfo";
            Constants.presenceState = "presenceState";
            Constants.presenceList = "presenceList";
            Constants.activityType = "activityType";
            Constants.sessionDetails = "sessionDetails";
            Constants.activityId = "activityId";
            Constants.Id = "id";
            Constants.notetext = "notetext";
            Constants.annotation = "annotation";
            Constants.entitySetName = "entitySetName";
            Constants.annotationId = "annotationid";
            Constants.secRemaining = "secs remaining";
            Constants.CollapseFlapHandler = "collapseFlapHandler";
            Constants.newSessionId = "newSessionId";
            Constants.previousSessionId = "previousSessionId";
            Constants.left = 1;
            Constants.right = 2;
            Constants.GLOBAL_PRESENCE_LIST = "GlobalToolBar_PresenceList";
            Constants.presenceText = "presenceText";
            Constants.presenceSelectControl = "presence_id";
            Constants.OK_BUTTON_ID = "ok_id";
            Constants.CANCEL_BUTTON_ID = "cancel_id";
            Constants.LAST_BUTTON_CLICKED = "param_lastButtonClicked";
            Constants.SET_PRESENCE_MDD = "SetAgentPresenceMDD";
            Constants.PRESENCE_SELECTED_VALUE = "param_selectedValue";
            Constants.CURRENT_PRESENCE_INFO = "GlobalToolBar_CurrentPresenceInfo";
            Constants.PRESENCE_BUTTON_DATA_ID = "[data-id='Microsoft.Dynamics.Service.CIFramework.Presence.Dialog']";
            Constants.PRESENCE_LIST_ID = "[id*='|NoRelationship||Microsoft.Dynamics.Service.CIFramework.Presence.DialogCommand']";
            Constants.sidePanelCollapsedState = 0;
            Constants.sidePanelExpandedState = 1;
            Constants.sidePanelHiddenState = 2;
            Constants.sessionNotValidErrorMessage = "Focused session is neither the default session nor it belongs to the provider";
            Constants.cifSolVersion = "msdyn_cifsolversion";
            Constants.correlationId = "correlationId";
            Constants.providerSessionId = "providerSessionId";
            Constants.errorMessage = "errorMsg";
            Constants.dialogStrings = "dialogStrings";
            Constants.dialogOptions = "dialogOptions";
            Constants.functionName = "functName";
            Constants.ErrorCode = "errorCode";
            Constants.notificationTemplateIconAttribute = "msdyn_icon";
            Constants.notificationTemplateIconDefaultValue = "/webresources/msdyn_chat_icon_zfp.svg";
            Constants.notificationTemplateTimeoutAttribute = "msdyn_timeout";
            Constants.templateName = "templateName";
            Constants.notificationTemplate = "notificationTemplate";
            Constants.templateParameters = "templateParameters";
            Constants.notificationTemplateTimeoutDefaultValue = 120;
            Constants.templateNameResolver = "templateNameResolver";
            Constants.notificationResponse = "NotificationResponse";
            Constants.isDelete = "isDelete";
            Constants.isDirty = "isDirty";
            Constants.onHiddenTimerEvent = "onHiddenTimerEvent";
            Constants.resetKpiBreach = "resetKpiBreach";
            Constants.kpiBreachDetails = "kpiBreachDetails";
            Constants.liveWorkItemEntity = "msdyn_ocliveworkitem";
            Constants.skipLwiCreation = "skipLwiCreation";
            Constants.idleTimeThreshold = "idleTimeThreshold";
            Constants.entityStateCode = "statecode";
            Constants.stateCodeClose = 3;
            Constants.entityStatusCode = "statuscode";
            Constants.statusCodeClose = 4;
            Constants.defaultSessionId = "session-id-0";
            Constants.OnKeyDownEvent = "keydown";
            Constants.defaultOmnichannelLabel = "omnichannel";
            Constants.defaultOmnichannelProviderId = "7E74C210-F8FF-4C16-84AF-5AE454A5514A";
            Constants.confirmButton = "confirmButton";
            Constants.result = "result";
            Constants.homeSession = "session-id-0";
            Constants.collection = "_collection";
            Constants.notificationOptions = "notificationOptions";
            Constants.globalMissedNotificationMessageBarId = "globalMissedNotificationMessageBarId";
            Constants.presenceCanUserSet = "canUserSet";
            Constants.inactivePresenceId = "a89ee9cf-453a-4b52-8d7a-ad647feecd5d";
            Constants.NotificationDisplayEvent = "notificationDisplayEvent";
            Constants.notificationAction = "notificationAction";
            Constants.OnWindowFocusEvent = "onWindowFocusEvent";
            Constants.OmniChannelProvider = "omnichannel";
            Constants.idle = "idle";
            Constants.WindowFocusEvent = "windowFocusEvent";
            Constants.progressIndicatorMessage = "progressIndicatorMessage";
            Constants.dialogName = "dialogName";
            Constants.dialogParams = "dialogParams";
            Constants.executeActionRequest = "executeActionRequest";
            Constants.executeActionMetadata = "executeActionMetadata";
            Constants.SearchType = "searchType";
            Constants.featureNameSpace = "featureNameSpace";
            Constants.featureUniqueName = "featureUniqueName";
            return Constants;
        })();
        CIFramework.Constants = Constants;
        let QueryDataConstants = /** @class */ (() => {
            class QueryDataConstants {
            }
            QueryDataConstants.SelectOperator = "?$select=";
            QueryDataConstants.FilterOperator = "$filter=";
            return QueryDataConstants;
        })();
        CIFramework.QueryDataConstants = QueryDataConstants;
        let ProductivityPaneConfigConstants = /** @class */ (() => {
            class ProductivityPaneConfigConstants {
            }
            ProductivityPaneConfigConstants.productivityPaneControlName = "MscrmControls.ProductivityToolPanel.ProductivityPanelControl";
            // Entity constants
            ProductivityPaneConfigConstants.entityName = "msdyn_productivitypaneconfiguration";
            // Attributes
            ProductivityPaneConfigConstants.productivityPaneState = "msdyn_productivitypanestate";
            ProductivityPaneConfigConstants.productivityPaneMode = "msdyn_productivitypanemode";
            ProductivityPaneConfigConstants.applicationName = "msdyn_applicationname";
            // tslint:disable-next-line:variable-name
            ProductivityPaneConfigConstants.msdyn_name = "msdyn_name";
            return ProductivityPaneConfigConstants;
        })();
        CIFramework.ProductivityPaneConfigConstants = ProductivityPaneConfigConstants;
        let AnalyticsConstants = /** @class */ (() => {
            class AnalyticsConstants {
            }
            AnalyticsConstants.notificationResponseAction = "notificationResponseAction";
            AnalyticsConstants.acceptNotificationResponse = "accepted";
            AnalyticsConstants.rejectNotificationResponse = "rejected";
            AnalyticsConstants.channelProviderName = "providerName";
            AnalyticsConstants.channelProviderId = "providerId";
            AnalyticsConstants.telemetryApiName = "telemetryAPIName";
            AnalyticsConstants.telemetryInitApiName = "InitCIFAnalytics";
            AnalyticsConstants.telemetryLogCustomEventApiName = "LogCustomEvent";
            AnalyticsConstants.telemetryLogSystemEventApiName = "LogSystemEvent";
            AnalyticsConstants.analyticsdata = "analyticsData";
            AnalyticsConstants.initLogAnalyticsEventName = "initAnalytics";
            AnalyticsConstants.analyticsEventType = "analyticsEventtype";
            AnalyticsConstants.analyticsEventName = "analyticsEventname";
            AnalyticsConstants.initAnalyticsPlatformEventName = "initCIFAnalytics";
            AnalyticsConstants.logAnalyticsPlatformEventName = "logCIFAnalytics";
            AnalyticsConstants.focussedSession = "focussedSession";
            AnalyticsConstants.clientSessionId = "clientSessionId";
            AnalyticsConstants.enableAnalytics = "enableAnalytics";
            AnalyticsConstants.telemetryUpdateConversationName = "updateConversation";
            AnalyticsConstants.updateConversationsPlatformEventName = "updateConversation";
            AnalyticsConstants.sessionUniqueId = "sessionUniqueId";
            AnalyticsConstants.correlationId = "correlationId";
            AnalyticsConstants.conversationId = "conversationId";
            AnalyticsConstants.providerSessionId = "providerSessionId";
            AnalyticsConstants.sessionStarted = "SessionStarted";
            AnalyticsConstants.SessionFocusIn = "SessionFocusIn";
            AnalyticsConstants.SessionFocusOut = "SessionFocusOut";
            AnalyticsConstants.sessionClosed = "SessionClosed";
            AnalyticsConstants.cifSessionStart = "cifSessionStart";
            AnalyticsConstants.cifSessionEnd = "cifSessionEnd";
            AnalyticsConstants.notificationReceived = "NotificationReceived";
            AnalyticsConstants.notificationAccepted = "NotificationAccepted";
            AnalyticsConstants.notificationRejected = "NotificationRejected";
            AnalyticsConstants.notificationTimedOut = "NotificationTimedOut";
            return AnalyticsConstants;
        })();
        CIFramework.AnalyticsConstants = AnalyticsConstants;
        let ResponseReason = /** @class */ (() => {
            class ResponseReason {
            }
            ResponseReason.Accept = "Accept";
            ResponseReason.AutoAcceptOnTimeout = "AutoAcceptOnTimeout";
            ResponseReason.AutoAccept = "AutoAccept";
            ResponseReason.DeclinedByAgent = "DeclinedByAgent";
            ResponseReason.DisplayTimeout = "DisplayTimeout";
            ResponseReason.NotificationQueueLimitExceeded = "NotificationQueueLimitExceeded";
            ResponseReason.NotificationQueueTimeLimitExceeded = "NotificationQueueTimeLimitExceeded";
            ResponseReason.NotificationTemplateNotFoundError = "NotificationTemplateNotFoundError";
            ResponseReason.NotificationTemplateResolverNotFoundError = "NotificationTemplateResolverNotFoundError";
            ResponseReason.RejectAfterTimeoutNonPlatformTimer = "RejectAfterTimeoutNonPlatformTimer";
            return ResponseReason;
        })();
        CIFramework.ResponseReason = ResponseReason;
        let NotificationState = /** @class */ (() => {
            class NotificationState {
            }
            NotificationState.DisplayStart = "DisplayStart";
            NotificationState.DisplayEnd = "DisplayEnd";
            return NotificationState;
        })();
        CIFramework.NotificationState = NotificationState;
        let ErrorCode;
        (function (ErrorCode) {
            ErrorCode[ErrorCode["Notes_Flap_Already_Expanded"] = 101] = "Notes_Flap_Already_Expanded"; // Notes flap is already expanded.
        })(ErrorCode = CIFramework.ErrorCode || (CIFramework.ErrorCode = {}));
        let EventType;
        (function (EventType) {
            EventType[EventType["SystemEvent"] = 0] = "SystemEvent";
            EventType[EventType["CustomEvent"] = 1] = "CustomEvent";
        })(EventType = CIFramework.EventType || (CIFramework.EventType = {}));
        let ShowTimeoutOption;
        (function (ShowTimeoutOption) {
            ShowTimeoutOption[ShowTimeoutOption["Yes"] = 100000000] = "Yes";
            ShowTimeoutOption[ShowTimeoutOption["No"] = 100000001] = "No";
        })(ShowTimeoutOption = CIFramework.ShowTimeoutOption || (CIFramework.ShowTimeoutOption = {}));
        let InternalEventName;
        (function (InternalEventName) {
            InternalEventName[InternalEventName["NotificationReceived"] = 0] = "NotificationReceived";
            InternalEventName[InternalEventName["NotificationAccepted"] = 1] = "NotificationAccepted";
            InternalEventName[InternalEventName["NotificationAutoAccepted"] = 2] = "NotificationAutoAccepted";
            InternalEventName[InternalEventName["NotificationRejected"] = 3] = "NotificationRejected";
            InternalEventName[InternalEventName["NotificationTimedOut"] = 4] = "NotificationTimedOut";
            InternalEventName[InternalEventName["SessionStarted"] = 5] = "SessionStarted";
            InternalEventName[InternalEventName["SessionFocusIn"] = 6] = "SessionFocusIn";
            InternalEventName[InternalEventName["SessionFocusOut"] = 7] = "SessionFocusOut";
            InternalEventName[InternalEventName["SessionClosed"] = 8] = "SessionClosed";
            InternalEventName[InternalEventName["NewTabOpened"] = 9] = "NewTabOpened";
            InternalEventName[InternalEventName["CifSessionStart"] = 10] = "CifSessionStart";
            InternalEventName[InternalEventName["CifSessionEnd"] = 11] = "CifSessionEnd";
        })(InternalEventName = CIFramework.InternalEventName || (CIFramework.InternalEventName = {}));
        let DesktopNotificationConstants = /** @class */ (() => {
            class DesktopNotificationConstants {
            }
            DesktopNotificationConstants.Granted = "granted";
            DesktopNotificationConstants.Denied = "denied";
            DesktopNotificationConstants.Default = "default";
            DesktopNotificationConstants.Accept = "accept";
            DesktopNotificationConstants.Reject = "reject";
            DesktopNotificationConstants.Never = 100000002;
            DesktopNotificationConstants.OnlyWhenPageNotInFocus = 100000003;
            DesktopNotificationConstants.InstalledEvent = "install";
            DesktopNotificationConstants.ActivateEvent = "activate";
            DesktopNotificationConstants.NotificationClickEvent = "notificationclick";
            DesktopNotificationConstants.MessageEvent = "message";
            DesktopNotificationConstants.BroadcastChannel = "BroadcastChannel";
            DesktopNotificationConstants.ServiceWorker = "serviceWorker";
            DesktopNotificationConstants.Error = "Error";
            DesktopNotificationConstants.timeoutBuffer = 5000;
            DesktopNotificationConstants.browserPrefixes = ['moz', 'ms', 'o', 'webkit'];
            return DesktopNotificationConstants;
        })();
        CIFramework.DesktopNotificationConstants = DesktopNotificationConstants;
        let MissedNotificationsConstants = /** @class */ (() => {
            class MissedNotificationsConstants {
            }
            MissedNotificationsConstants.MessageType = 2; // global message bar type
            MissedNotificationsConstants.Level = 3; // warning
            MissedNotificationsConstants.Title = ""; // warning
            MissedNotificationsConstants.ActionResourceKey = "RESET_PRESENCE_ACTION";
            MissedNotificationsConstants.MessageResourceKey = "MISSED_NOTIFICATION_MESSAGE_BAR_TEXT";
            MissedNotificationsConstants.PresencePlaceholderResourceKey = "MISSED_NOTIFICATION_PRESENCE_PLACEHOLDER";
            return MissedNotificationsConstants;
        })();
        CIFramework.MissedNotificationsConstants = MissedNotificationsConstants;
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * Wrapper for postMessage. This wrapper will be loaded on both widget and CI domains,
 * and will be the common messaging layer between these two. Without this layer,
 * postMessage acts as a common messaging API between the widget and CI.
 * This wrapper just wraps postMessage with more useful functionality of promises.

   Exposes a function postMsg that accepts a target window, a message and an origin
 */
/**
 * Creates a new type for mapping an open promise representing a postMessage call, against a correlation Id sent to the message receiver.
 */
/// <reference path="CIFrameworkConstants.ts" />
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        var postMessageNamespace;
        (function (postMessageNamespace) {
            // tslint:disable-next-line:class-name
            class postMsgWrapper {
                /**
                 * Creates and loads an instance of the wrapper on the CI or widget domain, wherever it is loaded
                 */
                constructor(listenerWindow, domains, handlers, responseTargetWindow) {
                    /**
                     * Collection for promises created on the caller (widget/CI), that represent open requests on the receiver (CI/widget)
                     */
                    this.pendingPromises = new Map();
                    this.messageHandlers = new Map();
                    this.responseTargetWindow = null;
                    // todo - ensure that there is always one listener for message event from CI side. For now: always removing previous one, if any, so that we only have one listener at a time.
                    if (listenerWindow) {
                        listenerWindow.removeEventListener(postMessageNamespace.messageConstant, this.processMessage.bind(this));
                        listenerWindow.addEventListener(postMessageNamespace.messageConstant, this.processMessage.bind(this));
                    }
                    // TO-DO, initialization of whitelisted domains may need to take a different path in future
                    this.listWhitelistedDomains = domains;
                    if (handlers) {
                        this.messageHandlers = handlers;
                    }
                    this.responseTargetWindow = responseTargetWindow;
                }
                /**
                 * Function for add handlers separate from the constructor
                 */
                addHandler(messageType, handler) {
                    if (this.messageHandlers.has(messageType)) {
                        this.messageHandlers.get(messageType).add(handler);
                    }
                    else {
                        this.messageHandlers.set(messageType, new Set().add(handler));
                    }
                }
                /**
                 * Function for getting handlers registered for an event
                 */
                getHandlers(messageType) {
                    if (this.messageHandlers.has(messageType)) {
                        return this.messageHandlers.get(messageType);
                    }
                    return null;
                }
                /**
                 * Function for remove a particular handler
                 */
                removeHandler(messageType, handler) {
                    if (!this.messageHandlers.has(messageType)) {
                        return;
                    }
                    this.messageHandlers.get(messageType).delete(handler);
                }
                /**
                 * Create a new correlation Id to map a promise against it, on the caller side (widget/CI)
                 */
                getCorrelationId() {
                    return (Math.random() + 1).toString(36).substring(7);
                }
                createDeferred(noTimeout) {
                    const deferred = {
                        promise: null,
                        resolve: null,
                        reject: null,
                        timerId: null,
                    };
                    const actualpromise = new Promise((resolve, reject) => {
                        deferred.resolve = resolve;
                        deferred.reject = reject;
                    });
                    const promises = [actualpromise];
                    if (!noTimeout) {
                        const timeout = new Promise((resolve, reject) => {
                            deferred.timerId = setTimeout(() => {
                                reject(Microsoft.CIFramework.Utility.createErrorMap("Timeout occurred as no response was received from listener window"));
                            }, postMessageNamespace.promiseTimeOut);
                        });
                        promises.push(timeout);
                    }
                    deferred.promise = Promise.race(promises).then((result) => {
                        if (deferred.timerId) {
                            clearTimeout(deferred.timerId);
                        }
                        this.removePromise(deferred);
                        return result;
                    }).catch((result) => {
                        if (deferred.timerId) {
                            clearTimeout(deferred.timerId);
                        }
                        this.removePromise(deferred);
                        throw result;
                    });
                    // TODO - if timed out, handle the deletion of orphaned actualPromise and scenario when actualpromise is resolved/rejected later on.
                    return deferred;
                }
                /**
                 * removes the entry from pendingPromises, given the value for that entry.
                 * @param deferred deferred object based on which entry should be deleted.
                 */
                removePromise(deferred) {
                    let keyToDelete = null;
                    for (const [key, value] of this.pendingPromises) {
                        if (value === deferred) {
                            keyToDelete = key;
                            break;
                        }
                    }
                    if (keyToDelete) {
                        this.pendingPromises.delete(keyToDelete);
                    }
                }
                /**
                 * Function on caller (widget/CI) to add a new correlation Id to a message, map a new promise against it and post the message to the receiver (CI/widget)
                 */
                // TO-DO in V2, check if the user should have resolve and reject exposed to send in their custom implementation
                postMsg(receivingWindow, message, targetOrigin, isEventFlag, noTimeout) {
                    if ((receivingWindow) && (targetOrigin !== "*")) {
                        const deferred = this.createDeferred(noTimeout);
                        const trackingCorrelationId = this.getCorrelationId();
                        const messageInternal = message;
                        messageInternal[postMessageNamespace.messageCorrelationId] = trackingCorrelationId;
                        this.pendingPromises.set(trackingCorrelationId, deferred);
                        return this.postMsgInternal(receivingWindow, messageInternal, targetOrigin, deferred);
                    }
                    else {
                        return postMessageNamespace.rejectWithErrorMessage("Receiving window or targetOrigin cannot be unspecified");
                    }
                }
                /**
                 * Internal function that post messages to the window with retry logic
                 * @param receivingWindow window to post message to
                 * @param message message to post
                 * @param targetOrigin target url
                 * @param deferred deferred object related with this message
                 */
                postMsgInternal(receivingWindow, message, targetOrigin, deferred) {
                    let retries = 0;
                    while (true) {
                        try {
                            receivingWindow.postMessage(message, targetOrigin);
                            if (deferred) {
                                return deferred.promise;
                            }
                            return;
                        }
                        catch (error) {
                            // todo - log the error and retries number.
                            if (++retries === postMessageNamespace.retryCount) {
                                return postMessageNamespace.rejectWithErrorMessage("Not able to post the request to receiving window after multiple tries.");
                            }
                        }
                    }
                }
                /**
                 * Function on receiver (widget/CI) to send back a response against an open request to the caller (CI/widget)
                 */
                sendResponseMsg(receivingWindow, message, targetOrigin) {
                    if ((receivingWindow) && (targetOrigin !== "*")) {
                        receivingWindow.postMessage(message, targetOrigin);
                    }
                }
                /**
                 * Common function on caller and receiver to process requests and responses
                 */
                processMessage(event) {
                    try {
                        const responseTargetWindow = this.responseTargetWindow || event.source;
                        const whiteListedOrigin = this.listWhitelistedDomains.find((whiteListedDomain) => {
                            // TODO - Replace URL with some other supported object if IE support becomes mandatory. URL is not supported by IE11
                            const domainUrl = new URL(event.origin);
                            const domainHostName = decodeURIComponent(domainUrl.hostname);
                            let whiteListedDomainUrl;
                            let whiteListedDomainHostName = "";
                            if (whiteListedDomain != null) {
                                whiteListedDomainUrl = new URL(whiteListedDomain);
                                whiteListedDomainHostName = decodeURIComponent(whiteListedDomainUrl.hostname);
                            }
                            if (whiteListedDomainHostName !== "" && whiteListedDomainHostName === domainHostName)
                                return true;
                            else if (whiteListedDomain != null && whiteListedDomainHostName.startsWith("*"))
                                return (domainHostName.endsWith(whiteListedDomainHostName.substr(2)));
                            return false;
                        });
                        const trackingCorrelationId = event.data[postMessageNamespace.messageCorrelationId];
                        let msg;
                        let messageData = null;
                        if (!event.origin || event.origin === "*" || !event.source) {
                            messageData = Microsoft.CIFramework.Utility.createErrorMap("Origin/Source of the message cant be null or all");
                        }
                        if (!whiteListedOrigin) {
                            messageData = Microsoft.CIFramework.Utility.createErrorMap("Sender domain is not a recognised or is invalid and hence the message cant be processed");
                        }
                        if (!trackingCorrelationId) {
                            if (messageData) {
                                // log message recieved has no correlation id, with origin & msg details
                                // tslint:disable-next-line:no-console
                                console.trace("Ignoring message from unknown event source: " + event.origin);
                                return;
                            }
                        }
                        else {
                            // correlation id exists, but the domain was not whitelisted. Return an error response
                            if (messageData) {
                                msg = {
                                    messageOutcome: postMessageNamespace.messageFailure,
                                    messageData,
                                    messageCorrelationId: trackingCorrelationId,
                                    messageType: postMessageNamespace.messageResponse
                                };
                                return this.sendResponseMsg(responseTargetWindow, msg, event.origin);
                            }
                        }
                        let pendingPromise;
                        if (trackingCorrelationId && this.pendingPromises) {
                            pendingPromise = this.pendingPromises.get(trackingCorrelationId);
                        }
                        /**
                         * If an open promise against this message's correlation Id does not exist,
                         * then invoke registered message handlers and send their result back
                         */
                        if (!pendingPromise) {
                            const data = event.data;
                            if (data.messageType === postMessageNamespace.messageResponse)
                                return; // This is a reponse message, directly return instead of processing.
                            if (typeof (data.messageData) !== "string")
                                data.messageData.set(postMessageNamespace.originURL, whiteListedOrigin);
                            /**
                             * Iterate through the handler list and invoke them all nd handle if there are no handlers
                             */
                            if (!this.messageHandlers.get(data.messageType)) {
                                if (trackingCorrelationId) {
                                    msg = {
                                        messageOutcome: postMessageNamespace.messageSuccess,
                                        messageData: Microsoft.CIFramework.Utility.createErrorMap("No handlers found to process the request."),
                                        messageCorrelationId: trackingCorrelationId,
                                        messageType: postMessageNamespace.messageResponse
                                    };
                                    this.sendResponseMsg(responseTargetWindow, msg, event.origin);
                                }
                                // todo - log that no handler was found alongwith message & origin details, and if we are sending back a response or silently ignoring.
                                return;
                            }
                            this.messageHandlers.get(data.messageType).forEach((handlerFunction) => {
                                try {
                                    handlerFunction(data.messageData).then(function (result) {
                                        if (trackingCorrelationId) {
                                            msg = {
                                                messageOutcome: postMessageNamespace.messageSuccess,
                                                messageData: result,
                                                messageCorrelationId: trackingCorrelationId,
                                                messageType: postMessageNamespace.messageResponse
                                            };
                                            this.sendResponseMsg(responseTargetWindow, msg, event.origin);
                                        }
                                    }.bind(this), function (error) {
                                        if (trackingCorrelationId) {
                                            msg = {
                                                messageOutcome: postMessageNamespace.messageFailure,
                                                messageData: error,
                                                messageCorrelationId: trackingCorrelationId,
                                                messageType: postMessageNamespace.messageResponse
                                            };
                                            this.sendResponseMsg(responseTargetWindow, msg, event.origin);
                                        }
                                    }.bind(this));
                                }
                                catch (error) {
                                    if (trackingCorrelationId) {
                                        msg = {
                                            messageOutcome: postMessageNamespace.messageFailure,
                                            messageData: Microsoft.CIFramework.Utility.buildMap(error),
                                            messageCorrelationId: trackingCorrelationId,
                                            messageType: postMessageNamespace.messageResponse
                                        };
                                        this.sendResponseMsg(responseTargetWindow, msg, event.origin);
                                    }
                                }
                            });
                        }
                        /**
                         * If an open promise against this message's correlation Id does exist,
                         * then process response as success/failure of an earlier request
                         * and delete the open promise from pendingPromises collection
                         */
                        else {
                            const data = event.data;
                            if (data.messageOutcome === postMessageNamespace.messageSuccess) {
                                pendingPromise.resolve(data.messageData);
                            }
                            else {
                                pendingPromise.reject(data.messageData);
                            }
                        }
                    }
                    catch (e) {
                        // tslint:disable-next-line:no-console
                        console.error("Error in PostMsgWrapper - processMessage. " + e);
                    }
                }
            }
            postMessageNamespace.postMsgWrapper = postMsgWrapper;
        })(postMessageNamespace = CIFramework.postMessageNamespace || (CIFramework.postMessageNamespace = {}));
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * ExecuteActionRequestParameterType class.
 */
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        class ExecuteActionRequestParameterType {
        }
        CIFramework.ExecuteActionRequestParameterType = ExecuteActionRequestParameterType;
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * ExecuteActionRequestParameter class.
 */
/// <reference path="ExecuteActionRequestParameterType.ts" />
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        class ExecuteActionRequestParameter {
        }
        CIFramework.ExecuteActionRequestParameter = ExecuteActionRequestParameter;
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * ExecuteActionOperationType enum.
 */
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        let ExecuteActionOperationType;
        (function (ExecuteActionOperationType) {
            ExecuteActionOperationType[ExecuteActionOperationType["Action"] = 0] = "Action";
        })(ExecuteActionOperationType = CIFramework.ExecuteActionOperationType || (CIFramework.ExecuteActionOperationType = {}));
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * ExecuteActionRequestBoundEntity class.
 */
/// <reference path="ExecuteActionRequestParameterType.ts" />
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        class ExecuteActionRequestBoundEntity {
        }
        CIFramework.ExecuteActionRequestBoundEntity = ExecuteActionRequestBoundEntity;
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * ExecuteActionRequest class.
 */
/// <reference path="ExecuteActionRequestParameter.ts" />
/// <reference path="ExecuteActionOperationType.ts" />
/// <reference path="ExecuteActionRequestBoundEntity.ts" />
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        class ExecuteActionRequest {
        }
        CIFramework.ExecuteActionRequest = ExecuteActionRequest;
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * ExecuteActionResponse class.
 */
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        class ExecuteActionResponse {
        }
        CIFramework.ExecuteActionResponse = ExecuteActionResponse;
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="../Runtime/ExecuteActionTypes//ExecuteActionRequest.ts" />
/// <reference path="../Runtime/ExecuteActionTypes//ExecuteActionResponse.ts" />
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        let targetWindow;
        let postMessage;
        const domains = [];
        const Constants = Microsoft.CIFramework.Constants;
        /**
         * utility func to check whether an object is null or undefined
         */
        /** @internal */
        function isNullOrUndefined(obj) {
            return (obj == null || typeof obj === "undefined");
        }
        CIFramework.isNullOrUndefined = isNullOrUndefined;
        /** @internal */
        function initialize() {
            const startTime = Date.now();
            targetWindow = window.top;
            const anchorElement = document.createElement("a");
            let anchorDomain = document.referrer;
            let crmUrl = "";
            try {
                const scriptTag = document.querySelector('script[' + Constants.ScriptIdAttributeName + '="' + Constants.ScriptIdAttributeValue + '"]');
                const crmDomain = scriptTag.getAttribute(Constants.ScriptCRMUrlAttributeName);
                if (crmDomain) {
                    anchorDomain = crmDomain;
                }
            }
            catch (error) {
                //
            }
            try {
                // Get the crmUrl from window.location
                crmUrl = Microsoft.CIFramework.Utility.extractParameter(window.location.search, Constants.UciLib);
            }
            catch (error) {
                //
            }
            anchorElement.href = anchorDomain;
            domains.push(anchorElement.protocol + "//" + anchorElement.hostname);
            if (crmUrl !== "" && crmUrl != null) {
                const anchor = document.createElement("a");
                anchor.href = crmUrl;
                domains.push(anchor.protocol + "//" + anchor.hostname);
            }
            if (domains.length > 1) {
                // To-Do Log the Message that more than one domains are present
            }
            postMessage = new CIFramework.postMessageNamespace.postMsgWrapper(window, domains, null, targetWindow);
            const dict = {};
            dict.detail = domains;
            const event1 = new CustomEvent(Constants.CIFInitEvent, dict);
            document.removeEventListener(Constants.OnKeyDownEvent, keyDownEvent);
            document.addEventListener(Constants.OnKeyDownEvent, keyDownEvent);
            document.removeEventListener("onclick", onUserActivity);
            document.removeEventListener("mousemove", onUserActivity);
            document.removeEventListener("touchstart", onUserActivity);
            document.addEventListener("onclick", onUserActivity);
            document.addEventListener("mousemove", onUserActivity);
            document.addEventListener("touchstart", onUserActivity);
            window.setTimeout(() => {
                window.dispatchEvent(event1);
            }, 0);
            function keyDownEvent(event) {
                onUserActivity();
                if ((event.shiftKey && event.altKey && event.ctrlKey) && (event.keyCode === 68)) {
                    // tslint:disable-next-line:no-console
                    console.log("Debug event: in widget code");
                    const payload = {
                        messageType: CIFramework.MessageType.debugInformationEvent,
                        messageData: new Map().set(Constants.value, "event form main lib ")
                    };
                    return sendMessage("debugInformationEvent", payload, false);
                }
                else {
                    return Promise.resolve();
                }
            }
            function onUserActivity() {
                // tslint:disable-next-line:no-console
                console.log("onUserActivity event: in widget code");
                const payload = {
                    messageType: CIFramework.MessageType.onUserActivity,
                    messageData: new Map().set(Constants.value, "event form main lib")
                };
                sendMessage(CIFramework.MessageType.onUserActivity, payload, false);
            }
        }
        /** @internal */
        function sendMessage(funcName, payload, isEvent, noTimeout) {
            const startTime = Date.now();
            return new Promise((resolve, reject) => {
                // domains contains the domains this widget can talk to , which is the CRM instance, so passing that as target origin.
                return postMessage.postMsg(targetWindow, payload, domains[domains.length - 1], false, noTimeout)
                    .then((result) => {
                    if (result && (!isNullOrUndefined(result.get(Constants.value)))) {
                        return resolve(result.get(Constants.value));
                    }
                    else {
                        return resolve(null);
                    }
                }, (error) => {
                    return reject(error);
                });
            });
        }
        /**
        * API to log telemetry errors for API failures
        */
        function logErrorsAndReject(errorMsg, messageType, correlationid) {
            const payload = {
                messageType: CIFramework.MessageType.logErrorsAndReject,
                messageData: new Map().set(Constants.errorMessage, errorMsg).set(Constants.correlationId, correlationid).set(Constants.functionName, messageType)
            };
            sendMessage(logErrorsAndReject.name, payload, false);
            return CIFramework.postMessageNamespace.rejectWithErrorMessage(errorMsg);
        }
        /**
         * API to to check value of IsConsoleApp for a widget
         *
         * @param value. When set to 'true', then it's a console App.
         *
        */
        function isConsoleApp() {
            const startTime = Date.now();
            const payload = {
                messageType: CIFramework.MessageType.isConsoleApp,
                messageData: new Map()
            };
            return sendMessage(isConsoleApp.name, payload, false);
        }
        CIFramework.isConsoleApp = isConsoleApp;
        /**
         * API to set/reset value of ClickToAct for a widget
         *
         * @param value. When set to 'true', invoke the registered 'onclicktoact' handler.
         *
        */
        function setClickToAct(value, correlationId) {
            if (isNullOrUndefined(value)) {
                value = false;
            }
            const payload = {
                messageType: CIFramework.MessageType.setClickToAct,
                messageData: new Map().set(Constants.value, value).set(Constants.correlationId, correlationId)
            };
            return sendMessage(setClickToAct.name, payload, false);
        }
        CIFramework.setClickToAct = setClickToAct;
        /**
         * API to insert notes control
         *
         * @param value. It's a string which contains session,activity details
         *
        */
        function insertNotes(entityName, entitySetName, entityId, annotationId, correlationId) {
            if (!(isNullOrUndefined(entityName) || isNullOrUndefined(entitySetName) || isNullOrUndefined(entityId))) {
                const payload = {
                    messageType: CIFramework.MessageType.insertNotes,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.entitySetName, entitySetName).set(Constants.entityId, entityId).set(Constants.annotationId, annotationId).set(Constants.correlationId, correlationId)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(insertNotes.name, payload, false, true).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityName)) {
                    const errorMsg = "The entityName parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.insertNotes, correlationId);
                }
                if (isNullOrUndefined(entitySetName)) {
                    const errorMsg = "The entitySetName parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.insertNotes, correlationId);
                }
                if (isNullOrUndefined(entityId)) {
                    const errorMsg = "The entityId parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.insertNotes, correlationId);
                }
            }
        }
        CIFramework.insertNotes = insertNotes;
        /**
         * API to close notes
        */
        function closeNotes(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.closeNotes,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(closeNotes.name, payload, false);
        }
        CIFramework.closeNotes = closeNotes;
        /**
         * API to invoke toast popup widget
         *
         * @param value. It's a string which contains header,body of the popup
         *
        */
        function notifyEvent(input, correlationId) {
            if (!isNullOrUndefined(input)) {
                const notificationMap = new Map();
                notificationMap.set(Constants.eventType, input.eventType);
                notificationMap.set(Constants.correlationId, correlationId);
                notificationMap.set(Constants.templateName, input.templateName);
                notificationMap.set(Constants.templateParameters, input.templateParameters);
                notificationMap.set(Constants.templateNameResolver, input.templateNameResolver);
                notificationMap.set(Constants.customParamsKey, input.additionalParametersObject);
                if (!isNullOrUndefined(input.notificationUXObject))
                    notificationMap.set(Constants.notificationUXObject, Microsoft.CIFramework.Utility.buildMap(JSON.parse(input.notificationUXObject)));
                const payload = {
                    messageType: CIFramework.MessageType.notifyEvent,
                    messageData: notificationMap
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(notifyEvent.name, payload, false, true).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                const errorMsg = "The Input parameter is blank. Provide a value.";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.notifyEvent, correlationId);
            }
        }
        CIFramework.notifyEvent = notifyEvent;
        /**
         * API to open the create form for given entity with data passed in pre-populated
         * Invokes the api Xrm.Navigation.openForm(entityFormOptions, formParameters)
         * https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/clientapi/reference/xrm-navigation/openform
         *
         * @param entityFormOptions. A JSON string encoding the entityFormOptions parameter of
         * the openForm API
         * @param entityFormParameters. A JSON string encoding the formParameters parameter
         * of the openForm API
         *
         * returns an Object Promise: The returned Object has the same structure as the underlying Xrm.Navigation.openForm() API
        */
        function openForm(entityFormOptions, entityFormParameters, correlationId) {
            if (!(isNullOrUndefined(entityFormOptions) || entityFormOptions === "")) {
                const payload = {
                    messageType: CIFramework.MessageType.openForm,
                    messageData: new Map().set(Constants.entityFormOptions, entityFormOptions).set(Constants.entityFormParameters, entityFormParameters).set(Constants.correlationId, correlationId)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(openForm.name, payload, false, true).then((result) => {
                        return resolve(JSON.stringify(result));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityFormOptions) || entityFormOptions === "") {
                    const errorMsg = "The EntityFormOptions parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.openForm, correlationId);
                }
            }
        }
        CIFramework.openForm = openForm;
        /**
         * API to refresh the main page if an entity form is currently opened
         *
         *
         * @param save. Optional boolean on whether to save the form on refresh
         * returns a boolean Promise
        */
        function refreshForm(save, correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.refreshForm,
                messageData: new Map().set(Constants.Save, save).set(Constants.correlationId, correlationId)
            };
            return new Promise((resolve, reject) => {
                return sendMessage(refreshForm.name, payload, false, false).then((result) => {
                    return resolve(JSON.stringify(result));
                }, (error) => {
                    return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                });
            });
        }
        CIFramework.refreshForm = refreshForm;
        /**
         * API to retrieve a given entity record based on entityId and oData query
         * Invokes the api Xrm.WebApi.retrieveRecord(entityName, entityId, options)
         * https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/clientapi/reference/xrm-webapi/retrieverecord
         *
         * @param entityName. The entity name to retrieve
         * @param entityId. The CRM record Id to retrieve
         *
         * @returns a map Promise: the result of the retrieve operation depending upon the query
        */
        function retrieveRecord(entityName, entityId, query, correlationId) {
            if (!(isNullOrUndefined(entityName) || entityName === "") && !(isNullOrUndefined(entityId) || entityId === "")) {
                const payload = {
                    messageType: CIFramework.MessageType.retrieveRecord,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.entityId, entityId).set(Constants.queryParameters, query).set(Constants.correlationId, correlationId)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(retrieveRecord.name, payload, false).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityName) || entityName === "") {
                    const errorMsg = "The EntityName parameter is blank.Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.retrieveRecord, correlationId);
                }
                if (isNullOrUndefined(entityId) || entityId === "") {
                    const errorMsg = "The EntityId parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.retrieveRecord, correlationId);
                }
            }
        }
        CIFramework.retrieveRecord = retrieveRecord;
        /**
         * API to update a given entity record based on entityId
         * Invokes the api Xrm.WebApi.updateRecord(entityName, entityId, data)
         * https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/clientapi/reference/xrm-webapi/updaterecord
         *
         * @param entityName. The entity name to retrieve
         * @param entityId. The CRM record Id to retrieve
         * @param data. A JSON string encoding the data parameter of the updateRecord XRM API
         *
         * @returns a map Promise: the result of the update operation
        */
        function updateRecord(entityName, entityId, data, correlationId) {
            if (!(isNullOrUndefined(entityName) || entityName === "") && !(isNullOrUndefined(entityId) || entityId === "") && !isNullOrUndefined(data)) {
                const payload = {
                    messageType: CIFramework.MessageType.updateRecord,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.entityId, entityId).set(Constants.value, Microsoft.CIFramework.Utility.buildMap(JSON.parse(data))).set(Constants.correlationId, correlationId)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(updateRecord.name, payload, false).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityName) || entityName === "") {
                    const errorMsg = "The EntityName parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.updateRecord, correlationId);
                }
                if (isNullOrUndefined(entityId) || entityId === "") {
                    const errorMsg = "The EntityId parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.updateRecord, correlationId);
                }
                if (isNullOrUndefined(data)) {
                    const errorMsg = "The data parameter is blank. Provide a value to the parameter to update the record.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.updateRecord, correlationId);
                }
            }
        }
        CIFramework.updateRecord = updateRecord;
        /**
         * API to create a new entity record based on passed data
         * Invokes the api Xrm.WebApi.createRecord(entityName, data)
         * https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/clientapi/reference/xrm-webapi/createrecord
         *
         * @param entityName. The entity name to retrieve
         * @param data. A JSON string encoding the data parameter of the createRecord XRM API
         *
         * @returns a map Promise: the result of the create operation
        */
        function createRecord(entityName, data, correlationId) {
            if (!(isNullOrUndefined(entityName) || entityName === "") && !isNullOrUndefined(data)) {
                const payload = {
                    messageType: CIFramework.MessageType.createRecord,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.value, Microsoft.CIFramework.Utility.buildMap(JSON.parse(data))).set(Constants.correlationId, correlationId)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(createRecord.name, payload, false).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityName) || entityName === "") {
                    const errorMsg = "The EntityName parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.createRecord, correlationId);
                }
                if (isNullOrUndefined(data)) {
                    const errorMsg = "Provide a value to the data parameter to create record.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.createRecord, correlationId);
                }
            }
        }
        CIFramework.createRecord = createRecord;
        /**
         * API to delete an entity record based on entityId
         * Invokes the api Xrm.WebApi.deleteRecord(entityName, entityId)
         * https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/clientapi/reference/xrm-webapi/deleterecord
         *
         * @param entityName. The entity name to delete
         * @param entityId. The record id to delete
         *
         * @returns a map Promise: the result of the delete operation
        */
        function deleteRecord(entityName, entityId, correlationid) {
            if (!(isNullOrUndefined(entityName) || entityName === "") && !(isNullOrUndefined(entityId) || entityId === "")) {
                const payload = {
                    messageType: CIFramework.MessageType.deleteRecord,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.entityId, entityId).set(Constants.correlationId, correlationid)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(deleteRecord.name, payload, false).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityName) || entityName === "") {
                    const errorMsg = "The EntityName parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.deleteRecord, correlationid);
                }
                if (isNullOrUndefined(entityId) || entityId === "") {
                    const errorMsg = "The EntityId parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.deleteRecord, correlationid);
                }
            }
        }
        CIFramework.deleteRecord = deleteRecord;
        /**
         * API to search records with respect to query parameters and open the respective record
         *
         * @param entityName. The name of the entity to search
         * @param queryParameter. An oData query string as supported by Dynamics CRM defining the search
         * @param searchOnly. When set to 'false', if the search record was a single record, open the record on the main UCI page
         * When set to 'true' return the search results but don't perform any navigation on the main page
         *
         * Returns a map Promise representing the search results as per the search query
        */
        function searchAndOpenRecords(entityName, queryParmeters, searchOnly, correlationid) {
            if (!(isNullOrUndefined(entityName) || entityName === "") && !(isNullOrUndefined(queryParmeters) || queryParmeters === "") && !(isNullOrUndefined(searchOnly))) {
                const payload = {
                    messageType: searchOnly ? CIFramework.MessageType.search : CIFramework.MessageType.searchAndOpenRecords,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.queryParameters, queryParmeters).set(Constants.searchOnly, searchOnly).set(Constants.correlationId, correlationid)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(searchAndOpenRecords.name, payload, false).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityName) || entityName === "") {
                    const errorMsg = "The EntityName parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.searchAndOpenRecords, correlationid);
                }
                if (isNullOrUndefined(queryParmeters) || queryParmeters === "") {
                    const errorMsg = "The queryParmeters parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.searchAndOpenRecords, correlationid);
                }
                if (isNullOrUndefined(searchOnly)) {
                    const errorMsg = "The searchOnly parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.searchAndOpenRecords, correlationid);
                }
            }
        }
        CIFramework.searchAndOpenRecords = searchAndOpenRecords;
        /**
         * API to get the Panel State
         *
         * @returns a Promise: '0' for minimized and '1' for docked mode
        */
        function getMode(correlationid) {
            const payload = {
                messageType: CIFramework.MessageType.getMode,
                messageData: new Map().set(Constants.correlationId, correlationid)
            };
            return sendMessage(getMode.name, payload, false);
        }
        CIFramework.getMode = getMode;
        /**
         * API to get the current main UCI page details
         *
         * @returns a Promise: map with available details of the current page
         *  'appid', 'pagetype', 'record-id' (if available), 'clientUrl', 'appUrl',
         * 'orgLcid', 'orgUniqueName', 'userId', 'userLcid', 'username', orgId
        */
        function getEnvironment(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.getEnvironment,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return new Promise((resolve, reject) => {
                return sendMessage(getEnvironment.name, payload, false).then((result) => {
                    return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                }, (error) => {
                    return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                });
            });
        }
        CIFramework.getEnvironment = getEnvironment;
        /**
         * API to get the Panel width
         *
         * @returns a Promise with the panel width
        */
        function getWidth(correlationId) {
            const startTime = Date.now();
            const payload = {
                messageType: CIFramework.MessageType.getWidth,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(getWidth.name, payload, false);
        }
        CIFramework.getWidth = getWidth;
        /**
         * API to call the openkbsearch control
         *
         * @params value. search string
        */
        function openKBSearchControl(value, correlationId) {
            const startTime = Date.now();
            if (!isNullOrUndefined(value)) {
                const payload = {
                    messageType: CIFramework.MessageType.openKBSearchControl,
                    messageData: new Map().set(Constants.SearchString, value).set(Constants.correlationId, correlationId)
                };
                return sendMessage(openKBSearchControl.name, payload, false);
            }
            else {
                const errorMsg = "The openKBSearchControl parameter value is invalid. Provide a positive number to the parameter.";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.openKBSearchControl, correlationId);
            }
        }
        CIFramework.openKBSearchControl = openKBSearchControl;
        /**
         * API to set the Panel width
         *
         * @params value. The panel width to be set in pixels
        */
        function setWidth(value) {
            const startTime = Date.now();
            if (!isNullOrUndefined(value) && value >= 0) {
                const payload = {
                    messageType: CIFramework.MessageType.setWidth,
                    messageData: new Map().set(Constants.value, value)
                };
                return sendMessage(setWidth.name, payload, false);
            }
            else {
                const errorMsg = "The setWidth parameter value is invalid. Provide a positive number to the parameter.";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.setWidth, "");
            }
        }
        CIFramework.setWidth = setWidth;
        /**
         * API to set the Panel State
         *
         * @params value. The mode to set on the panel, '0' - minimized, '1' - docked, '2' - hidden
        */
        function setMode(value, correlationId) {
            const startTime = Date.now();
            if (!isNullOrUndefined(value) && (value === 0 || value === 1 || value === 2)) {
                const payload = {
                    messageType: CIFramework.MessageType.setMode,
                    messageData: new Map().set(Constants.value, value).set(Constants.correlationId, correlationId)
                };
                return sendMessage(setMode.name, payload, false);
            }
            else {
                const errorMsg = "The setMode paramter value must be 0, 1 or 2.";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.setMode, correlationId);
            }
        }
        CIFramework.setMode = setMode;
        /**
         * API to check the whether clickToAct functionality is enabled or not
         *
         * @returns a boolean Promise on whether ClickToAct is currently enabled
        */
        function getClickToAct(correlationId) {
            const startTime = Date.now();
            const payload = {
                messageType: CIFramework.MessageType.getClickToAct,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(getClickToAct.name, payload, false);
        }
        CIFramework.getClickToAct = getClickToAct;
        /**
         * API to add the subscriber for the named event
         *
         * @params eventName. The event for which to set the handler. The currently supported events are
         *  'onclicktoact' - when a click-to-act enabled field is clicked by the agent
         *  'onmodechanged' - when the panel mode is manually toggled between 'minimized' and 'docked'
         *  'onsizechanged' - when the panel size is manually changed by dragging
         *  'onpagenavigate' - triggered before a navigation event occurs on the main page
         *  'onsendkbarticle' - triggered when the agent clicks on the 'send KB Article' button on the KB control
         * @params func. The handler function to invoke on the event
         */
        function addHandler(eventName, handlerFunction, correlationId) {
            const startTime = Date.now();
            if (!(isNullOrUndefined(eventName) || eventName === "") && !isNullOrUndefined(handlerFunction)) {
                postMessage.addHandler(eventName, handlerFunction);
                const payload = {
                    messageType: CIFramework.MessageType.addGenericHandler,
                    messageData: new Map().set(Constants.eventType, eventName).set(Constants.correlationId, correlationId)
                };
                sendMessage("addGenericHandler", payload, false);
            }
            else {
                if (isNullOrUndefined(eventName) || eventName === "") {
                    const errorMsg = "The parameter EventName is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.addGenericHandler, correlationId);
                }
                if (isNullOrUndefined(handlerFunction)) {
                    const errorMsg = "Passing data parameters to addHandler is mandatory.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.addGenericHandler, correlationId);
                }
            }
        }
        CIFramework.addHandler = addHandler;
        /**
         * API to remove the subscriber
         */
        function removeHandler(eventName, handlerFunction, correlationId) {
            const startTime = Date.now();
            if (!(isNullOrUndefined(eventName) || eventName === "") && !isNullOrUndefined(handlerFunction)) {
                postMessage.removeHandler(eventName, handlerFunction);
                const payload = {
                    messageType: CIFramework.MessageType.removeGenericHandler,
                    messageData: new Map().set(Constants.eventType, eventName).set(Constants.correlationId, correlationId)
                };
                sendMessage("removeGenericHandler", payload, false);
            }
            else {
                if (isNullOrUndefined(eventName) || eventName === "") {
                    const errorMsg = "The EventName parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.removeGenericHandler, correlationId);
                }
                if (isNullOrUndefined(handlerFunction)) {
                    const errorMsg = "Passing data parameters to removeHandler is mandatory.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.removeGenericHandler, correlationId);
                }
            }
        }
        CIFramework.removeHandler = removeHandler;
        /**
         * API to get the EntityMetadata
         * Invokes the API Xrm.Utility.getEntityMetadata(entityName, attributes)
         * https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/clientapi/reference/xrm-utility/getentitymetadata
         * @params entityName - Name of the Entity whose metadata is to be fetched
         * attributes - The attributes to get metadata for
         *
         * @returns a Promise: JSON String with available metadata of the current entity
        */
        function getEntityMetadata(entityName, attributes, correlationId) {
            if (!(isNullOrUndefined(entityName) || entityName === "")) {
                const payload = {
                    messageType: CIFramework.MessageType.getEntityMetadata,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.Attributes, attributes).set(Constants.correlationId, correlationId)
                };
                return sendMessage(getEntityMetadata.name, payload, false);
            }
            else {
                if (isNullOrUndefined(entityName) || entityName === "") {
                    const errorMsg = "The EntityName parameter is blank. Provide a value to the parameter";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.getEntityMetadata, correlationId);
                }
            }
        }
        CIFramework.getEntityMetadata = getEntityMetadata;
        /**
         * API to search based on the Search String
         * Invokes the API Xrm.Navigation.navigateTo(PageInput)
         * @param entityName -Name of the Entity for which the records are to be fetched
         * @param searchString - String based on which the search is to be made
         * @param correlationId - String Used to group all related API calls together for diagnostic telemetry
         * @param searchType - Number Optional parameter for defining search type(0 - Relevance search or 1 - customised search).
         */
        function renderSearchPage(entityName, searchString, correlationId, searchType) {
            if (!(isNullOrUndefined(entityName) || entityName === "") && !(isNullOrUndefined(searchString))) {
                const payload = {
                    messageType: CIFramework.MessageType.renderSearchPage,
                    messageData: new Map().set(Constants.entityName, entityName).set(Constants.SearchString, searchString).set(Constants.correlationId, correlationId).set(Constants.SearchType, searchType)
                };
                return sendMessage(renderSearchPage.name, payload, false);
            }
            else {
                if (isNullOrUndefined(entityName) || entityName === "") {
                    const errorMsg = "The EntityName Parameter is blank. Provide a value to the parameter";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.renderSearchPage, correlationId);
                }
                if (isNullOrUndefined(searchString)) {
                    const errorMsg = "The SearchString Parameter cannot be NULL";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.renderSearchPage, correlationId);
                }
            }
        }
        CIFramework.renderSearchPage = renderSearchPage;
        /**
         * API to set the agent presence
         * Invokes the API setAgentPresence(presenceInfo)
         * @param presenceInfo - Details of the Presence to be set for the Agent
    
         * @returns a Promise: Boolean Status after setting the Agent Presence
         */
        function setAgentPresence(presenceInfo, correlationId) {
            if (!(isNullOrUndefined(presenceInfo))) {
                const payload = {
                    messageType: CIFramework.MessageType.setAgentPresence,
                    messageData: new Map().set(Constants.presenceInfo, presenceInfo).set(Constants.correlationId, correlationId)
                };
                return sendMessage(setAgentPresence.name, payload, false);
            }
            else {
                const errorMsg = "The presenceInfo parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.setAgentPresence, correlationId);
            }
        }
        CIFramework.setAgentPresence = setAgentPresence;
        /**
         * API to set the agent presence
         * Invokes the API setPresence(presenceState)
         * @param presenceState - Details of the Presence to be set for the Agent
    
         * @returns a Promise: Boolean Status after setting the Agent Presence
         */
        function setPresence(presenceState, correlationId) {
            if (!(isNullOrUndefined(presenceState))) {
                const payload = {
                    messageType: CIFramework.MessageType.setPresence,
                    messageData: new Map().set(Constants.presenceState, presenceState).set(Constants.correlationId, correlationId)
                };
                return sendMessage(setPresence.name, payload, false);
            }
            else {
                const errorMsg = "The presencestate parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.setPresence, correlationId);
            }
        }
        CIFramework.setPresence = setPresence;
        /**
         * API to get the agent presence
         * Invokes the API getPresence()
         * @param presenceState
         * @returns a Promise: Boolean Status after setting the Agent Presence
         */
        function getPresence(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.getPresence,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(getPresence.name, payload, false);
            const errorMsg = "The getPresence function somehow got error";
            return logErrorsAndReject(errorMsg, CIFramework.MessageType.getPresence, correlationId);
        }
        CIFramework.getPresence = getPresence;
        /**
         * API to get all Sessions
         */
        function getAllSessions(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.getAllSessions,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(getAllSessions.name, payload, false);
        }
        CIFramework.getAllSessions = getAllSessions;
        /**
         * API to get focused Session
         */
        function getFocusedSession(correlationid) {
            const payload = {
                messageType: CIFramework.MessageType.getFocusedSession,
                messageData: new Map().set(Constants.correlationId, correlationid)
            };
            return sendMessage(getFocusedSession.name, payload, false);
        }
        CIFramework.getFocusedSession = getFocusedSession;
        /**
         * API to get Session details
         */
        function getSession(sessionId, correlationid) {
            if (!(isNullOrUndefined(sessionId) || sessionId === "")) {
                const payload = {
                    messageType: CIFramework.MessageType.getSession,
                    messageData: new Map().set(Constants.sessionId, sessionId).set(Constants.correlationId, correlationid)
                };
                return sendMessage(getSession.name, payload, false);
            }
            else {
                const errorMsg = "The sessionId parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.getSession, correlationid);
            }
        }
        CIFramework.getSession = getSession;
        /**
         * API to check if a new Session can be created
         */
        function canCreateSession(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.canCreateSession,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(canCreateSession.name, payload, false);
        }
        CIFramework.canCreateSession = canCreateSession;
        /**
         * API to get the value of an fcb
         */
        function getFcsValue(featureNameSpace, featureUniqueName, correlationId) {
            if (!featureNameSpace || !featureUniqueName)
                return null;
            const payload = {
                messageType: CIFramework.MessageType.getFcsValue,
                messageData: new Map().set(Constants.featureNameSpace, featureNameSpace).set(Constants.featureUniqueName, featureUniqueName).set(Constants.correlationId, correlationId)
            };
            return sendMessage(getFcsValue.name, payload, false);
        }
        CIFramework.getFcsValue = getFcsValue;
        /**
         * API to create Session
         */
        function createSession(input, correlationId, providerSessionId) {
            if (!isNullOrUndefined(input)) {
                let customerName = input.customerName;
                if (isNullOrUndefined(customerName) && !isNullOrUndefined(input.templateParameters)) {
                    customerName = input.templateParameters.customerName;
                }
                const payload = {
                    messageType: CIFramework.MessageType.createSession,
                    messageData: new Map().set(Constants.input, input).set(Constants.context, input.context).set(Constants.customerName, customerName).set(Constants.correlationId, correlationId).set(Constants.providerSessionId, providerSessionId)
                };
                return sendMessage(createSession.name, payload, false, true);
            }
            else {
                const errorMsg = "Some of required parameters are null";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.createSession, correlationId);
            }
        }
        CIFramework.createSession = createSession;
        /**
         * API to notify incoming on an invisible Session
         */
        function requestFocusSession(sessionId, messagesCount, correlationId) {
            if (!isNullOrUndefined(sessionId)) {
                const payload = {
                    messageType: CIFramework.MessageType.requestFocusSession,
                    messageData: new Map().set(Constants.sessionId, sessionId).set(Constants.messagesCount, messagesCount).set(Constants.correlationId, correlationId)
                };
                return sendMessage(requestFocusSession.name, payload, false);
            }
            else {
                const errorMsg = "SessionID is null or undefined";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.requestFocusSession, correlationId);
            }
        }
        CIFramework.requestFocusSession = requestFocusSession;
        /**
    * API to notify the KPI Breach
    */
        function notifyKpiBreach(sessionId, shouldReset, details, correlationId) {
            if (!isNullOrUndefined(sessionId)) {
                const payload = {
                    messageType: CIFramework.MessageType.notifyKpiBreach,
                    messageData: new Map().set(Constants.sessionId, sessionId).set(Constants.resetKpiBreach, shouldReset).set(Constants.kpiBreachDetails, details).set(Constants.correlationId, correlationId)
                };
                return sendMessage(notifyKpiBreach.name, payload, false);
            }
            else {
                const errorMsg = "SessionID is null or undefined";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.notifyKpiBreach, correlationId);
            }
        }
        CIFramework.notifyKpiBreach = notifyKpiBreach;
        /**
    * API to notify the new activity on the session
    */
        function notifyNewActivity(sessionId, count, shouldReset, correlationId) {
            if (!isNullOrUndefined(sessionId)) {
                const payload = {
                    messageType: CIFramework.MessageType.notifyNewActivity,
                    messageData: new Map().set(Constants.sessionId, sessionId).set(Constants.messagesCount, count)
                        .set(Constants.shouldReset, shouldReset).set(Constants.correlationId, correlationId)
                };
                return sendMessage(notifyNewActivity.name, payload, false);
            }
            else {
                const errorMsg = "SessionID is null or undefined";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.notifyNewActivity, correlationId);
            }
        }
        CIFramework.notifyNewActivity = notifyNewActivity;
        /**
         * API to get the focused tab in focused Session
         */
        function getFocusedTab(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.getFocusedTab,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(getFocusedTab.name, payload, false);
        }
        CIFramework.getFocusedTab = getFocusedTab;
        /**
         * API to get the focused tab in focused Session
         */
        function getTabs(name, tag, correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.getTabsByTagOrName,
                messageData: new Map().set(Constants.templateTag, tag).set(Constants.nameParameter, name).set(Constants.correlationId, correlationId)
            };
            return sendMessage(getTabs.name, payload, false);
        }
        CIFramework.getTabs = getTabs;
        function refreshTab(tabId, correlationId) {
            if (!isNullOrUndefined(tabId)) {
                const payload = {
                    messageType: CIFramework.MessageType.refreshTab,
                    messageData: new Map().set(Constants.tabId, tabId).set(Constants.correlationId, correlationId)
                };
                return sendMessage(refreshTab.name, payload, false);
            }
            else {
                const errorMsg = "The tabId Parameter is blank. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.refreshTab, correlationId);
            }
        }
        CIFramework.refreshTab = refreshTab;
        function setSessionTitle(input, correlationId) {
            if (!isNullOrUndefined(input)) {
                const payload = {
                    messageType: CIFramework.MessageType.setSessionTitle,
                    messageData: new Map().set(Constants.input, input).set(Constants.correlationId, correlationId)
                };
                return sendMessage(setSessionTitle.name, payload, false);
            }
            else {
                const errorMsg = "The input Parameter is blank. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.setSessionTitle, correlationId);
            }
        }
        CIFramework.setSessionTitle = setSessionTitle;
        function setTabTitle(tabId, input, correlationId) {
            if (!isNullOrUndefined(input) && !isNullOrUndefined(tabId)) {
                const payload = {
                    messageType: CIFramework.MessageType.setTabTitle,
                    messageData: new Map().set(Constants.input, input).set(Constants.tabId, tabId).set(Constants.correlationId, correlationId)
                };
                return sendMessage(setTabTitle.name, payload, false);
            }
            else {
                if (isNullOrUndefined(tabId)) {
                    const errorMsg = "The tabId Parameter is blank. Provide a value to the parameter";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.setTabTitle, correlationId);
                }
                if (isNullOrUndefined(input)) {
                    const errorMsg = "The input Parameter cannot be NULL";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.setTabTitle, correlationId);
                }
            }
        }
        CIFramework.setTabTitle = setTabTitle;
        /**
     * API to create a Tab in home Session
     */
        function createTabInHomeSession(input, correlationId) {
            if (!isNullOrUndefined(input)) {
                const payload = {
                    messageType: CIFramework.MessageType.createTabInHomeSession,
                    messageData: new Map().set(Constants.input, input).set(Constants.correlationId, correlationId)
                };
                return sendMessage(createTabInHomeSession.name, payload, false);
            }
            else {
                const errorMsg = "Some of the required parameters are Null";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.createTabInHomeSession, correlationId);
            }
        }
        CIFramework.createTabInHomeSession = createTabInHomeSession;
        /**
         * API to create a Tab in focused Session
         */
        function createTab(input, correlationId) {
            if (!isNullOrUndefined(input)) {
                const payload = {
                    messageType: CIFramework.MessageType.createTab,
                    messageData: new Map().set(Constants.input, input).set(Constants.correlationId, correlationId)
                };
                return sendMessage(createTab.name, payload, false);
            }
            else {
                const errorMsg = "Some of the required parameters are Null";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.createTab, correlationId);
            }
        }
        CIFramework.createTab = createTab;
        /**
         * API to focus a Tab in focused Session
         */
        function focusTab(tabId, correlationId) {
            if (!isNullOrUndefined(tabId)) {
                const payload = {
                    messageType: CIFramework.MessageType.focusTab,
                    messageData: new Map().set(Constants.tabId, tabId).set(Constants.correlationId, correlationId)
                };
                return sendMessage(focusTab.name, payload, false);
            }
            else {
                const errorMsg = "tabId is null or undefined";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.focusTab, correlationId);
            }
        }
        CIFramework.focusTab = focusTab;
        /**
         * API to close a Tab in focused Session
         */
        function closeTab(tabId, correlationId) {
            if (!isNullOrUndefined(tabId) && tabId.trim() != "") {
                const payload = {
                    messageType: CIFramework.MessageType.closeTab,
                    messageData: new Map().set(Constants.tabId, tabId).set(Constants.correlationId, correlationId)
                };
                return sendMessage(closeTab.name, payload, false);
            }
            else {
                const errorMsg = "tabId is null or undefined";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.focusTab, correlationId);
            }
        }
        CIFramework.closeTab = closeTab;
        /**
         * API to set all the presences
        * Invokes the API initializeAgentPresenceList(presenceList)
        * @param presenceList - Array containing all the available Presences
    
        * @returns a Promise: Boolean Status after setting the list of presences
        */
        function initializeAgentPresenceList(presenceList, correlationId) {
            if (!(isNullOrUndefined(presenceList))) {
                const payload = {
                    messageType: CIFramework.MessageType.initializeAgentPresenceList,
                    messageData: new Map().set(Constants.presenceList, presenceList).set(Constants.correlationId, correlationId)
                };
                return sendMessage(initializeAgentPresenceList.name, payload, false);
            }
            else {
                const errorMsg = "The presenceList parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.initializeAgentPresenceList, correlationId);
            }
        }
        CIFramework.initializeAgentPresenceList = initializeAgentPresenceList;
        /**
         * API to update conversation data
        * @param data - Object containing the conversation data
        * @returns a Promise: JSON String with status message
        */
        function updateConversation(entityId, data, correlationId) {
            if (!(isNullOrUndefined(entityId) || entityId === "") && !isNullOrUndefined(data)) {
                const payload = {
                    messageType: CIFramework.MessageType.updateConversation,
                    messageData: new Map().set(Constants.entityName, Constants.liveWorkItemEntity).set(Constants.entityId, entityId).set(Constants.value, Microsoft.CIFramework.Utility.buildMap(JSON.parse(data))).set(Constants.correlationId, correlationId)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(updateConversation.name, payload, false).then((result) => {
                        return resolve(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(result)));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                if (isNullOrUndefined(entityId) || entityId === "") {
                    const errorMsg = "The EntityId parameter is blank. Provide a value to the parameter.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.updateConversation, correlationId);
                }
                if (isNullOrUndefined(data)) {
                    const errorMsg = "The data parameter is blank. Provide a value to the parameter to update the record.";
                    return logErrorsAndReject(errorMsg, CIFramework.MessageType.updateConversation, correlationId);
                }
            }
        }
        CIFramework.updateConversation = updateConversation;
        /**
         * API to log a custom analytics event
        * @param data - Object containing the event data
        * @returns a Promise: JSON String with status message
        */
        function logAnalyticsEvent(data, eventName, correlationId) {
            if (!isNullOrUndefined(data) || !isNullOrUndefined(eventName)) {
                const payload = {
                    messageType: CIFramework.MessageType.logAnalyticsEvent,
                    messageData: new Map().set(CIFramework.AnalyticsConstants.analyticsdata, data)
                        .set(Constants.correlationId, correlationId)
                        .set(CIFramework.AnalyticsConstants.analyticsEventName, eventName)
                        .set(CIFramework.AnalyticsConstants.analyticsEventType, CIFramework.EventType.CustomEvent)
                };
                return sendMessage(logAnalyticsEvent.name, payload, false);
            }
            else {
                const errorMsg = "logAnalyticsEvent payload data or eventType is not valid. ";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.logAnalyticsEvent, correlationId);
            }
        }
        CIFramework.logAnalyticsEvent = logAnalyticsEvent;
        /**
         * API to set automation dictionary
        * Invokes the API updateContext
        * @param input - List of parameters to be updated in form of json input, array of strings for deleting parameters
        * @returns a Promise with template parameters
        */
        function updateContext(input, sessionId, isDelete, correlationId) {
            if (!isNullOrUndefined(input)) {
                const payload = {
                    messageType: CIFramework.MessageType.updateContext,
                    messageData: new Map().set(Constants.input, input).set(Constants.sessionId, sessionId).set(Constants.isDelete, isDelete).set(Constants.correlationId, correlationId)
                };
                return sendMessage(updateContext.name, payload, false);
            }
            else {
                const errorMsg = "The input parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.updateContext, correlationId);
            }
        }
        CIFramework.updateContext = updateContext;
        function openDialog(dialogStrings, dialogOptions, correlationId) {
            if (!isNullOrUndefined(dialogStrings)) {
                const payload = {
                    messageType: CIFramework.MessageType.openDialog,
                    messageData: new Map().set(Constants.dialogStrings, dialogStrings).set(Constants.dialogOptions, dialogOptions).set(Constants.correlationId, correlationId)
                };
                return new Promise((resolve, reject) => {
                    return sendMessage(openDialog.name, payload, false, true).then((result) => {
                        return resolve(JSON.stringify(result));
                    }, (error) => {
                        return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                    });
                });
            }
            else {
                const errorMsg = "The dialogStrings parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.openDialog, correlationId);
            }
        }
        CIFramework.openDialog = openDialog;
        function openMDDDialog(dialogName, dialogOptions, dialogParams, correlationId) {
            if (!isNullOrUndefined(dialogName)) {
                const payload = {
                    messageType: CIFramework.MessageType.openMDDDialog,
                    messageData: new Map().set(Constants.dialogName, dialogName).set(Constants.dialogOptions, dialogOptions).set(Constants.dialogParams, dialogParams).set(Constants.correlationId, correlationId)
                };
                return sendMessage(openMDDDialog.name, payload, false, true);
            }
            else {
                const errorMsg = "The dialogName parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.openDialog, correlationId);
            }
        }
        CIFramework.openMDDDialog = openMDDDialog;
        /**
        * API to show Global Notification
        *  @param notificationOptions - Object containing the notification options
        */
        function showGlobalNotification(notificationOptions, correlationId) {
            if (!isNullOrUndefined(notificationOptions)) {
                const payload = {
                    messageType: CIFramework.MessageType.showGlobalNotification,
                    messageData: new Map().set(Constants.notificationOptions, notificationOptions)
                        .set(Constants.correlationId, correlationId)
                };
                return sendMessage(showGlobalNotification.name, payload, false, true);
            }
            else {
                const errorMsg = "The notificationOptions parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.showGlobalNotification, correlationId);
            }
        }
        CIFramework.showGlobalNotification = showGlobalNotification;
        /**
        * API to clear Global Notification
        *  @param notificationId - Id of the global notification that needs to be cleared
        */
        function clearGlobalNotification(notificationId) {
            if (!isNullOrUndefined(notificationId)) {
                const payload = {
                    messageType: CIFramework.MessageType.clearGlobalNotification,
                    messageData: new Map().set(Constants.notificationId, notificationId)
                };
                return sendMessage(clearGlobalNotification.name, payload, false, true);
            }
            else {
                const errorMsg = "The notificationId parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.clearGlobalNotification);
            }
        }
        CIFramework.clearGlobalNotification = clearGlobalNotification;
        /**
         * API to execute fetch query
         *
         * @param entityName Entity name - please provide the plural name
         * @param options
         *		Following formats can be used
                    https://docs.microsoft.com/en-us/powerapps/developer/model-driven-apps/clientapi/reference/xrm-webapi/retrievemultiplerecords
                    https://docs.microsoft.com/en-us/powerapps/developer/model-driven-apps/clientapi/reference/xrm-webapi/retrieverecord
                    To fetch file data
                        options = "/({recordID}/{fileAttributeName}"
        */
        function executeFetchQuery(entityName, options) {
            const payload = {
                messageType: CIFramework.MessageType.executeFetchQuery,
                messageData: new Map().set(Constants.entityName, entityName).set(Constants.options, options)
            };
            return new Promise((resolve, reject) => {
                return sendMessage(executeFetchQuery.name, payload, false).then((result) => {
                    return resolve(JSON.stringify(result));
                }, (error) => {
                    return reject(JSON.stringify(Microsoft.CIFramework.Utility.buildEntity(error)));
                });
            });
        }
        CIFramework.executeFetchQuery = executeFetchQuery;
        /**
        * API to show Progress Indicator
        *  @param message - string to be displayed
        * https://docs.microsoft.com/en-us/powerapps/developer/model-driven-apps/clientapi/reference/xrm-utility/showprogressindicator
        */
        function showProgressIndicator(message, correlationId) {
            if (!isNullOrUndefined(message)) {
                const payload = {
                    messageType: CIFramework.MessageType.showProgressIndicator,
                    messageData: new Map().set(Constants.progressIndicatorMessage, message).set(Constants.correlationId, correlationId)
                };
                return sendMessage(showProgressIndicator.name, payload, false);
            }
            else {
                const errorMsg = "The message parameter is null. Provide a value to the parameter";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.showProgressIndicator);
            }
        }
        CIFramework.showProgressIndicator = showProgressIndicator;
        /**
        * API to close Progress Indicator
        * https://docs.microsoft.com/en-us/powerapps/developer/model-driven-apps/clientapi/reference/xrm-utility/closeprogressindicator
        */
        function closeProgressIndicator(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.closeProgressIndicator,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(closeProgressIndicator.name, payload, false);
        }
        CIFramework.closeProgressIndicator = closeProgressIndicator;
        /** API to show missed notification message bar
        * Invokes the API showTimeoutGlobalNotification()
        * @returns a Promise: Notification Id of timeout notification
        */
        function showTimeoutGlobalNotification(correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.showTimeoutGlobalNotification,
                messageData: new Map().set(Constants.correlationId, correlationId)
            };
            return sendMessage(showTimeoutGlobalNotification.name, payload, false);
        }
        CIFramework.showTimeoutGlobalNotification = showTimeoutGlobalNotification;
        /**
        * API to execute unbound actions
        * @param request - Object containing the action request
        *
        * Usage examples:
        * ```typescript
        * const result1 = Microsoft.CIFramework.executeAction({operationName: "ActionWithoutParameters", operationType: 0});
        * const result2 = Microsoft.CIFramework.executeAction({operationName: "ActionWithStringParameter", operationType: 0, parameters: [{name: "ParameterName", value: "ParameterValue", type: {structuralProperty: 1, typeName: "Edm.String"}}]});
        * ```
        */
        function executeAction(request, correlationId) {
            const payload = {
                messageType: CIFramework.MessageType.executeAction,
                messageData: new Map().set(Constants.executeActionRequest, request).set(Constants.correlationId, correlationId)
            };
            return sendMessage(executeAction.name, payload, false);
        }
        CIFramework.executeAction = executeAction;
        /**
         * API to get raise a custom event on the platform side
         * @param eventName - Event Name registered in the platform.
         * @param eventInput - JSON string input of the data to be passed to the registered event at the platform.
         * @param correlationId - The LiveWorkItemID
        */
        function raiseEvent(eventName, eventInput, correlationId) {
            if (isNullOrUndefined(eventName)) {
                const errorMsg = "raiseEvent payload data does not have eventName. ";
                return logErrorsAndReject(errorMsg, CIFramework.MessageType.raiseEvent, correlationId);
            }
            const payload = {
                messageType: eventName,
                messageData: new Map().set(Constants.value, eventInput).set(Constants.correlationId, correlationId)
            };
            return sendMessage(raiseEvent.name, payload, false);
        }
        CIFramework.raiseEvent = raiseEvent;
        initialize();
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
//# sourceMappingURL=msdyn_ciLibrary.js.map