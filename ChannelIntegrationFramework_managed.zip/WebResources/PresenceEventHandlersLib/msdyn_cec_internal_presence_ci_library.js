/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/** @internal */
var Microsoft;
(function (Microsoft) {
    var CIFramework;
    (function (CIFramework) {
        var Internal;
        (function (Internal) {
            let PresenceDialogControl = /** @class */ (() => {
                class PresenceDialogControl {
                    // Empty Constructor
                    constructor() {
                        //
                    }
                    static get Instance() {
                        if (this.instance == null) {
                            this.instance = new PresenceDialogControl();
                        }
                        return this.instance;
                    }
                    /**
                     * utility func to check whether an object is null or undefined
                     */
                    /** @internal */
                    isNullOrUndefined(obj) {
                        return (obj == null || typeof obj === "undefined");
                    }
                    openPresenceDialogonLoad(e) {
                        let presenceControl = Xrm.Page.getControl(PresenceDialogControl.presenceSelectControl);
                        if (this.isNullOrUndefined(presenceControl)) {
                            const that = this;
                            setTimeout(() => {
                                presenceControl = Xrm.Page.getControl(PresenceDialogControl.presenceSelectControl);
                                that.loadPresenceControlOptions(presenceControl);
                            }, 500);
                        }
                        else {
                            this.loadPresenceControlOptions(presenceControl);
                        }
                    }
                    openPresenceDialogOKClick(executionContext) {
                        const presenceSelectControl = Xrm.Page.getControl(PresenceDialogControl.presenceSelectControl);
                        // tslint:disable-next-line:no-console
                        const presenceSelectControlAttr = presenceSelectControl ? presenceSelectControl.getAttribute() : console.log("presenceSelectControl is null");
                        // tslint:disable-next-line:no-console
                        const presenceValue = presenceSelectControlAttr ? presenceSelectControlAttr.getValue() : console.log("presenceSelectControlAttr is null");
                        if (!this.isNullOrUndefined(presenceValue)) {
                            const presenceControlOptions = presenceSelectControl.getOptions();
                            for (let i = 0; i < presenceControlOptions.length; i++) {
                                if (presenceControlOptions[i].value === presenceValue) {
                                    Xrm.Page.data.attributes.get(PresenceDialogControl.PRESENCE_SELECTED_VALUE).setValue(presenceControlOptions[i].text);
                                    this.raiseSetPresenceFromDialog(presenceControlOptions[i].text);
                                    break;
                                }
                            }
                        }
                        Xrm.Page.data.attributes.get(PresenceDialogControl.LAST_BUTTON_CLICKED).setValue(PresenceDialogControl.OK_BUTTON_ID);
                        const formContext = executionContext.getFormContext();
                        formContext.ui.close();
                    }
                    openPresenceDialogCancelClick(executionContext) {
                        Xrm.Page.data.attributes.get(PresenceDialogControl.LAST_BUTTON_CLICKED).setValue(PresenceDialogControl.CANCEL_BUTTON_ID);
                        const formContext = executionContext.getFormContext();
                        formContext.ui.close();
                    }
                    raiseSetPresenceFromDialog(searchText) {
                        const presenceOptionsstr = window.localStorage[PresenceDialogControl.GLOBAL_PRESENCE_LIST];
                        const presenceList = JSON.parse(presenceOptionsstr);
                        const updatedPresence = {};
                        let selectedStatus = {};
                        if (presenceList && searchText) {
                            for (let i = 0; i < presenceList.length; i++) {
                                if (presenceList[i].presenceText === searchText) {
                                    selectedStatus = presenceList[i];
                                    break;
                                }
                            }
                        }
                        if (selectedStatus) {
                            updatedPresence.presenceId = selectedStatus.presenceId;
                            updatedPresence.presenceText = selectedStatus.presenceText;
                            updatedPresence.presenceColor = selectedStatus.presenceColor;
                            updatedPresence.basePresenceStatus = selectedStatus.basePresenceStatus;
                            const setPresenceEvent = new CustomEvent('setPresenceEvent', {
                                detail: { "presenceId": updatedPresence.presenceId, "presenceInfo": updatedPresence }
                            });
                            window.parent.dispatchEvent(setPresenceEvent);
                        }
                    }
                    loadPresenceControlOptions(presenceControl) {
                        presenceControl.setFocus();
                        const presenceOptionsstr = window.localStorage[PresenceDialogControl.GLOBAL_PRESENCE_LIST];
                        const currentPresencestr = window.localStorage[PresenceDialogControl.CURRENT_PRESENCE_INFO];
                        if (presenceOptionsstr && currentPresencestr) {
                            const presenceOptions = JSON.parse(presenceOptionsstr);
                            const currentPresence = JSON.parse(currentPresencestr);
                            if (presenceControl && presenceOptions) {
                                for (let i = 0; i < presenceOptions.length; i++) {
                                    const item = {
                                        text: presenceOptions[i][PresenceDialogControl.presenceText],
                                        value: i
                                    };
                                    if (presenceOptions[i].hasOwnProperty(PresenceDialogControl.presenceCanUserSet)) {
                                        if (presenceOptions[i][PresenceDialogControl.presenceCanUserSet]) {
                                            presenceControl.addOption(item);
                                        }
                                    }
                                    else {
                                        presenceControl.addOption(item);
                                    }
                                    if (presenceOptions[i][PresenceDialogControl.presenceText] === currentPresence.presenceText) {
                                        presenceControl.getAttribute().setValue(i);
                                        const presenceButton = window.top.document.querySelector(PresenceDialogControl.PRESENCE_BUTTON_DATA_ID);
                                    }
                                }
                            }
                        }
                    }
                }
                PresenceDialogControl.presenceSelectControl = "presence_id";
                PresenceDialogControl.GLOBAL_PRESENCE_LIST = "GlobalToolBar_PresenceList";
                PresenceDialogControl.CURRENT_PRESENCE_INFO = "GlobalToolBar_CurrentPresenceInfo";
                PresenceDialogControl.presenceText = "presenceText";
                PresenceDialogControl.presenceCanUserSet = "canUserSet";
                PresenceDialogControl.PRESENCE_BUTTON_DATA_ID = "[data-id='Microsoft.Dynamics.Service.CIFramework.Presence.Dialog']";
                PresenceDialogControl.PRESENCE_SELECTED_VALUE = "param_selectedValue";
                PresenceDialogControl.CANCEL_BUTTON_ID = "cancel_id";
                PresenceDialogControl.LAST_BUTTON_CLICKED = "param_lastButtonClicked";
                PresenceDialogControl.OK_BUTTON_ID = "ok_id";
                return PresenceDialogControl;
            })();
            Internal.PresenceDialogControl = PresenceDialogControl;
        })(Internal = CIFramework.Internal || (CIFramework.Internal = {}));
    })(CIFramework = Microsoft.CIFramework || (Microsoft.CIFramework = {}));
})(Microsoft || (Microsoft = {}));
//# sourceMappingURL=msdyn_cec_internal_presence_ci_library.js.map